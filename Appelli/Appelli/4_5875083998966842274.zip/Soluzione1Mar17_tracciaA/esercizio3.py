import sys
from operator import *

def leggiF1(nomeFile):
    data = []
    try:
        with open (nomeFile) as fp:
            content = fp.readlines()
            for line in content:
                linea=line.split()
				#newlinea=(linea[0],linea[1],float(linea[2])
                data.append(linea)
    except Exception as e:
        print('Errore: %s' % e)
        sys.exit(1)
    #for x in range(0,len(data['nome'])):
        #print data['nome'][x],data['regista'][x],data['incasso'][x]
    return data

def leggiF2(nomeFile):
    data = []
    try:
        with open(nomeFile) as fp:
            content=fp.readlines()
            for line in content:
                linea=line.split()
                data.append(linea)
    except Exception as e:
            print('Errore %s' % e)
            sys.exit(1)
    #for x in range(0,len(data['film'])):
        #print data['film'][x],data['attore'][x]
    return data

def punto2(film):
	#Stampare i 10 film che hanno ottenuto il maggior incasso al box office.
    diz = {}
   
    for nomefilm, nomereg, incasso in film:
            diz[nomefilm]=incasso
    lista = sorted(diz.items(), key=itemgetter(1),reverse=True)
    cont=0
    print ("I 10 film che hanno ottenuto il maggior incasso al box office")
    for h,k in lista:
        if cont<10:
            print (cont+1,":", h,k)
            cont=cont+1

def punto3(attori):
#Stampare la lista degli attori ordinata per numero di film in cui hanno recitato (crescente).
    diz = {}
    for nomefilm, nomeattore in attori:
        if nomeattore in diz:
            diz[nomeattore] += 1
        else:
            diz[nomeattore] = 1
            
    maggioriF=sorted(diz.items(),key=itemgetter(1))
    print ("la lista degli attori ordinata per numero di film in cui hanno recitato (crescente)")
    for i,j in maggioriF:
        print (i,j)

def punto4(film,attori):
#Stampare la lista dei registi ordinata per numero di attori (decrescente) che hanno diretto e, a parità, per incasso totale dei film che hanno diretto (crescente).
#posso costruire un dizionario con chiave regista e valore   numattori,  l'incasso totale e la la lista degli attori (anche se non richiesta dalla traccia)
    dizFilmRegista={}
    dizRegisti = {}
    #inserisco gli incassi  e costruisco il dizionario film -> regista
    for nomefilm, nomereg, incasso in film:
        if nomereg not in dizRegisti:
            x=[0,float(incasso),[]]
            dizRegisti[nomereg]=x
        else:
            dizRegisti[nomereg][1]+=float(incasso)
        if nomefilm not in dizFilmRegista:
            dizFilmRegista[nomefilm]=nomereg   
    #inserisco gli attori
    for nomefilm, nomeattore in attori:
        nomereg=dizFilmRegista[nomefilm]
        #si suppone che il regista ci sia sempre nel dizionario, a meno di un'inconsistenza dei dati
        dizRegisti[nomereg][0]+=1
        dizRegisti[nomereg][2].append(nomeattore)     
    #Nota x[1][0] rappresenta il numero di attori e x[1[1] l'incasso, moltiplico l'incasso per -1 in modo da ordinare in maniera opposta 
    #avrei potuto anche fare ordinato=sorted(dizRegisti.items(),key=lambda x: (-1*x[1][0],x[1][2]))
    ordinato=sorted(dizRegisti.items(),key=lambda x: (x[1][0],-1*x[1][2]), reverse=True)
    print ("la lista  ordinata per numero di attori (decrescente) che hanno diretto e, a parità, per incasso totale dei film che hanno diretto (crescente)")
    for i,j in ordinato:
        print (i,j)
   
   
def cercaR(diz2,regista):
    j=0
    for word in diz2['registi']:
        if word != regista:
            j = j+1
        else:
            return j
    return -1


def attoriInF(gata,nome):
    cont=0
    for word in gata['film']:
        if word == nome:
            cont+=1
    return cont

def cerca(data,nome):
    j=0
    for word in data['nome']:
        if word == nome:
            return data['regista'][j]
        else:
            j+=1
    return -1
    
def stampa (lista):
	for i in lista:
		for j in i:
			print (j)
		print

if __name__ == '__main__':
    if len(sys.argv) == 3:
        fname = sys.argv[1]
        gname = sys.argv[2]
        film = leggiF1(fname)
        attori = leggiF2(gname)
        #stampa (film)
        #stampa (attori)
        punto2(film)
        punto3(attori)
        punto4(film,attori)
    else:
        print('Usage: %s <file_film> <file_attori>' % sys.argv[0])
        sys.exit(1)
