#include <stdio.h>

int main(){
    int c=2,b=10;
    int *a;
    a=&b;
    c=*a;
    printf("Valore a:%d\n",*a);
    printf("Valore b:%d\n",b);
    printf("Valore c:%d\n",c);
}
