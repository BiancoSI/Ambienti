#include <stdio.h>

int main(){
    char stringa[20];
    scanf("%s",stringa);
    printf("%s\n",stringa);
    return 0;
}
