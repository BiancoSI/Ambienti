#include <stdio.h>
int calcolo(int a,int b){
    if(a>b)
        return a;
    return b;

}

int main(){
    printf("Calcolare max");
    int a,b=15,max;
    scanf("%d",&a);
    scanf("%d",&b);
    max=calcolo(a,b);
    printf("Il massimo è %d\n",max);
    return 0;
}

