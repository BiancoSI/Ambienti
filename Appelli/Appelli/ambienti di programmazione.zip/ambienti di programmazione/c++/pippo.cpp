#include<iostream>
#define N 5

int main(){
    int x[N];
    int c=0;
    while (c!=N){
        scanf("%d",&x[c]);
        c=c+1;    
    }
    c=0;
    while (c!=N){
        printf("Ciao a tutti %d \n",x[c]);
        c=c+1;    
    };
    return 0;
}
