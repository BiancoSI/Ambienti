#include <stdio.h>
#include <stdlib.h>
float** create(int,int);
void definisciMatrice(float**,int,int);
void riempiMatrice(float**,int,int);
void stampaMatrice(float**,int,int);
float puntoSella(float**,int,int);
bool maxRiga(flot**,int,int,int)
bool minCol(flot**,int,int,int)
bool minRiga(flot**,int,int,int)
bool maxRiga(flot**,int,int,int)
int main(){
    float **m;
    int rig,col;
    printf("Inserisci il numero delle righe");
    scanf("%d",&rig);
    printf"Inserisci il numero delle colonne");
    scanf("%d",&col);
    m=create(rig,col);
    definisciMatrice(m,rig,col);
    riempiMatrice(m,rig,col);
    stampaMatrice(m,rig,col);
    int rigSella,colSella;
    float sella=puntoSella(m,rig,col,&rigSella,&colSella);
    return 0;
}

float creare(int rig,int col){
    float **m;
    int i;
    m=(float**)malloc(rig*sizeof(float*));
    if(m==NULL){
        printf("MEMORIA NON DISPONIBILE");
        exit(-1);
    } else {
        for(i=0;i<rig;i++){
            m[i]=(float*)malloc(c*sizeof(float));
            if(m[i]==null){
                printf("MEMORIA NON DISPONIBILE");
                free(m);
                exit(-1);
            }
        }
        
    }
    return m;
}
void definisciMatrice(float** m,int rig,int col){
    int i,j;
    for (int i=0;i<rig,i++){
        for(int j=0;j<col,j++){
            m[i][j]=0;        
        }
    }
}
void riempiMatrice(float** m,int rig,int col){
    int i,j;
    for (int i=0;i<rig,i++){
        for(int j=0;j<col,j++){
            printf("m[%d,%d]<",i,j);
            scanf("%f",&m[i][j];        
        }
    }
void stampaMatrice(float** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("%f ",m[i][j]);
        }
        printf("\n");
    }
}
void puntoSella(float** m,int rig,int col,int* rigSella,int* colSella){
    float pSella=-1;    
    int rigSella=0;
    int colSella=0;
    int i,j;
    for (int i=0;i<rig,i++){
        for(int j=0;j<col,j++){
              if((maxRiga(**m,m[i][j],i,col) && minCol(m,m[i][j],j,rig)) || (minRiga(m,m[i][j],i,col) && maxCol(m,m[i][j],j,rig)){
                    *rigSella=i;
                    *colSella=j;
                    return m[i][j];
        }
    }
}
bool maxRiga(float** m,int num,int rigCorrente,int col)
    int j;
    for(j=0,j<col;j++){
        if(num<m[rigCorrente][j]){
            return false;
        }
    }
    return true;
}
bool minRiga(float** m,int num,int rigCorrente,int col)
    int j;
    for(j=0,j<col;j++){
        if(num>m[rigCorrente][j]){
            return false;
        }
    }
    return true;
}
bool minCol(float** m,int num,int colCorrente,int rig)
    int i;
    for(i=0,i<rig;j++){
        if(num>m[i][colCorrente]){
            return false;
        }
    }
    return true;
}
bool maxCol(float** m,int num,int colCorrente,int rig)
    int i;
    for(i=0,i<rig;j++){
        if(num<m[i][colCorrente]){
            return false;
        }
    }
    return true;
}


}
