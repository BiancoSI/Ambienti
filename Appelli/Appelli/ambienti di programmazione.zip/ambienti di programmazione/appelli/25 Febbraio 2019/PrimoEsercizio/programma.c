#include <stdio.h>
#include <stdlib.h>

typedef enum {false,true} bool;

int** create(int,int);
void read(int**,int,int);
void print(int**,int,int);
bool somma_minima(int**,int,int,int*,int*,int*);

int main(){
    int **m,rig,col;
    printf("Numero righe: ");
    scanf("%d",&rig);
    printf("Numero colonne: ");
    scanf("%d",&col);
    m=create(rig,col);
    read(m,rig,col);
    print(m,rig,col);
    int valore,riga,colonna;
    if(somma_minima(m,rig,col,&valore,&riga,&colonna))
        printf("Metodo somma minima: %d valore, %d riga, %d colonna.",valore,riga,colonna);
    else
        printf("Metodo somma minima non trovato.");
    return 0;
}

bool somma_minima(int **m,int rig,int col,int* valOk,int* rigOk,int* colOk){
    int i,j,k;
    int sommaRiga=0;
    int sommaColonna=0;
    int temp=0;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            temp=m[i][j]*col;
            for(k=0;k<col;k++){//sommaRiga
                sommaRiga=sommaRiga+m[i][k];
            }
            for(k=0;k<rig;k++){//sommaCOlonna
                sommaColonna=sommaColonna+m[k][j];
            }
            if(temp>sommaRiga && temp<sommaColonna){
                *valOk=m[i][j];
                *rigOk=i;
                *colOk=j;
                return true;
            }
            sommaRiga=0;
            sommaColonna=0;
            temp=0;
        }
    }
    return false;
}


int** create(int rig,int col){
    int **m,i;
    m=(int**)malloc(rig*sizeof(int*));
    if(m==NULL){
        printf("Memoria non disponibile.");
        exit(2);
    }
    for(i=0;i<rig;i++){
        m[i]=(int*)malloc(col*sizeof(int));
        if(m[i]==NULL){
            printf("Memoria non disponibile");
            free(m);
            exit(2);
        }
    }
    return m;
}

void read(int** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("Inserisci numero nella matrice alla riga %d e colonna %d: ",i,j);
            scanf("%d",&m[i][j]);
        }
    }
}

void print(int** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("%d ",m[i][j]);
        }
        printf("\n");
    }
}
