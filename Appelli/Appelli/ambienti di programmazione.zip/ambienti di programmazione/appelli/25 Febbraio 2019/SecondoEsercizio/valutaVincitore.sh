# valutaVincitore.sh <cartellaCandidati> <FileVinc>
if [ ! -d $1 ];then
    echo "Errore stringa. Esempio: valutaVincitore.sh <cartellaCandidati> <FileVinc>"
    exit -1
fi
if [ ! -f $2 ];then
    echo "Errore stringa. Esempio: valutaVincitore.sh <cartellaCandidati> <FileVinc>"
    exit -1
fi
if [ $# -ne 2 ];then
    echo "Errore stringa. Esempio: valutaVincitore.sh <cartellaCandidati> <FileVinc>"
else
    cartellaCandidati=$(ls $1)
    nomeFile=''
    votiTot=0
    for i in $cartellaCandidati;do
        fileTemp=$(cat $1/$i)
        votiTemp=0
        for j in $fileTemp;do
            let votiTemp=$votiTemp+$j
        done
        if [ $votiTot -lt $votiTemp ];then
            votiTot=$votiTemp
            nomeFile=$i
        fi
    done
    file=$( echo -n $nomeFile|sed -s "s/.txt//" )
    echo "$file $votiTot punti." >> $2
fi
