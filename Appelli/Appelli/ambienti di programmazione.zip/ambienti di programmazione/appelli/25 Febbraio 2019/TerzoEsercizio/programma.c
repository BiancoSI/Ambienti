#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    int fd,pid,pos,pFmul2[2],pFmul3[2],stringheFmul3[2],status,num;
    if(pipe(pFmul2)==-1){
        printf("Errore durante la creazione della pipe");
        exit(2);
    }
    if(pipe(pFmul3)==-1){
        printf("Errore durante la creazione della pipe");
        exit(2);
    }
    if(pipe(stringheFmul3)==-1){
        printf("Errore durante la creazione della pipe");
        exit(2);
    }
    pos=1;
    pid=fork();
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore nella creazione del processo");
        exit(2);
    }
    if(pid==0){
        if(pos){//figlio pFmul2
            int pNipote[2];
            if(pipe(pNipote)==-1){
                printf("Errore nella creazione del processo");
                exit(2);
            }
            pid=10
            pid=fork();
            int ciclo=1;
            if(pid>0){//nipote
                int somma=0;
                while(ciclo){
                    read(pNipote[0],&num,sizeof(int));
                    if(num==0)
                        ciclo=num;
                    somma=somma+num;
                }
                int fd=open("Media.txt",O_CREAT|OWRONLY);
                lseek(fd,0,SEEK_SET);
                char numero[5]=
            } else {
                while(ciclo){
                    read(pFmul2[0],&num,sizeof(int));
                    if(num==0)
                        ciclo=num;
                    write(pNipote[1],&num,sizeof(int));
                }
                wait(&status);
            }               
        } else { //figlio pFmul3
            int ciclo=1
            int cinque[5];
            while(ciclo){
                read(pFmul3[0],&num,sizeof(int));
                if(num==0)
                    ciclo=num;
                if(num>5)
                    cinque="sup 5";
                if(num<5) 
                    cinque="inf 5";
                write(stringheFmul3,&cinque,5);
            }
        }
    } else { //padre
        fd=open("fileBinario",O_RDONLY);
        int lungFile=lseek(fd,0,SEEK_END);
        lseek(fd,0,SEEK_SET);
        char cinque[5];
        for(i=0;i<lungFile;i++){
            read(fd,&num,sizeof(int));
            if(num%2==0)
                write(pFmul2[1],&num,sizeof(int));
            if(num%3==0){
                write(pFmul3[1],&num,sizeof(int));
                read(stringheFmul3[0],&cinque,5);
                printf("%s \n",cinque);
            }
        }
        num=0//indico la fine
        write(pFmul2[1],&num,sizeof(int));
        write(pFmul3[1],&num,sizeof(int));  
        
        
    }
    return 0;
}
