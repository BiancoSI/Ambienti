#include <stdio.h>
#include <stdlib.h>

int main(){
    int a=20;
    char c=a-'0';
    printf("%s",c);
}  
        
