#include <stdlib.h>
#include <stdio.h>


float** create(int,int);
void read(float**,int,int);
void print(float**,int,int);
void verifica_vet_matrice(float**,int,int,int*,int*,float*);
float* riempiV(int);

int main(){
    float **m;
    int rig,col,vetUguale,vetContenuto;
    printf("Inserisci numero di righe della matrice: ");
    scanf("%d",&rig);
    printf("Inserisci numero delle colonne della matrice: ");
    scanf("%d",&col);
    m=create(rig,col);
    read(m,rig,col);
    print(m,rig,col);
    float *V;
    V=riempiV(col);
    verifica_vet_matrice(m,rig,col,&vetUguale,&vetContenuto,V);
    printf("vetUguale %d \n",vetUguale);
    printf("vetContenuto %d \n",vetContenuto);
    return 0;
}

void verifica_vet_matrice(float** m,int rig,int col,int* vetUguale,int* vetContenuto,float* v){
    int i,j,k,contaUguale,contaContenuto;
    *vetUguale=0;
    *vetContenuto=0;
    contaUguale=0;
    contaContenuto=0;
    for(i=0;i<col;i++){
        for(j=0;j<rig;j++){
            if(m[j][i]==v[j])
                contaUguale++;
            for(k=0;k<col;k++){
                if(m[j][i]==v[k]){
                    contaContenuto++;
                    break;
                }
            }
        }
    if((contaUguale+2)>col)
        *vetUguale=*vetUguale+1;
    if(contaContenuto==col)
        *vetContenuto=*vetContenuto+1;
    contaUguale=0;
    contaContenuto=0;
    }
}

float* riempiV(int rig){
    int i;
    float *v;
    v=(float*)malloc(rig*sizeof(float));
    if(v==NULL){
        printf("Memoria non disponibile.");
        exit(-1);
    }
    for(i=0;i<rig;i++){
        printf("Inserisci elemento vettore alla riga %d: ",i);
        scanf("%f",&v[i]);
    }
    for(i=0;i<rig;i++){
        printf("%f ",v[i]);
    }
    printf("\n");
    return v;
}

float** create(int rig,int col){
    float **m;
    int i;
    m=(float**)malloc(rig*sizeof(float*));
    if(m==NULL){
        printf("Memoria non disponibile.");
        exit(2);
    }
    for(i=0;i<rig;i++){
        m[i]=(float*)malloc(col*sizeof(float));
        if(m[i]==NULL){
            printf("Memoria non disponibile");
            free(m);
            exit(1);
            }
    }
    return m;
}

void read(float** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("Inserisci elemento matrice alla riga %d colonna %d: ",i,j);
            scanf("%f",&m[i][j]);
        }
    }
}

void print(float** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++)
            printf("%f ",m[i][j]);
        printf("\n");
    }
}
