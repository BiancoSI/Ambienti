#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

void calcolaOccorrenza(int* buffer){
    int ciclo=1,occ=0,num;
    while(ciclo){
        if(read(buffer[0],&num,sizeof(int))<0)break;
        if(num)
            occ++;
        else
            ciclo=num;
        }
        write(buffer[1],&occ,sizeof(int));
        exit(2);
}


int main(){
    int pid,pos,pF1[2],pF2[2],status;
    if(pipe(pF1)==-1){
        printf("Errore durante la creazione della pipe");
        exit(-1);
    }
    if(pipe(pF2)==-1){
        printf("Errore durante la creazione della pipe");
        exit(-1);
    }
    pos=1;
    printf("main \n");
     int *v,lung,i;
        printf("Inserisci lunghezza vettore: ");
        scanf("%d",&lung);
        v=(int*)malloc(lung*sizeof(int));
        for(i=0;i<lung;i++){
            printf("Inserisci %d elemento: ",i);
            scanf("%d",&v[i]);
        }
        for(i=0;i<lung;i++){
            if(v[i]==18)
                write(pF1[1],&v[i],sizeof(int));
            if(v[i]==30)
                write(pF2[1],&v[i],sizeof(int));
        }
        i=0;//INDICO AI FIGLI CHE IL PROGRAMMA HA TERMINATO IL CONTROLLO SUL VETTORE.
        write(pF1[1],&i,sizeof(int));
        write(pF2[1],&i,sizeof(int));
    pid=fork();
    
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore durante la creazione del processo.");
        exit(-1);
    }
    if(pid==0){
        if(pos){//figlio1
            calcolaOccorrenza(pF1);
        } //fine figlio 1
        else {//figlio 2 & nipote
            int pNipote[2];
            if(pipe(pNipote)==-1){
                printf("Errore durante la creazione della pipe");
                exit(-1);
            }
            pid=fork();
            if(pid>0){//figlio2
                int ciclo=1,num;
                while(ciclo){
                    read(pF2[0],&num,sizeof(int));
                    write(pNipote[1],&num,sizeof(int));
                    if(num==0)
                        ciclo=num;
                }
                wait(&status);
                read(pNipote[0],&num,sizeof(int));
                write(pF2[1],&num,sizeof(int));
            } //fine figlio 2
            else {//nipote
                calcolaOccorrenza(pNipote);
            }
        } //fine figlio 2 & nipote
    } else {//padre
        int occ18,occ30,maggiore;
        FILE *fd;
        wait(&status);wait(&status);
        read(pF1[0],&occ18,sizeof(int));   
        read(pF2[0],&occ30,sizeof(int));
        fd=fopen("output.txt","w+");
        if(fd==NULL){
            printf("Errore nell'apertura del file.");
            exit(-1);
        }
        if(occ18>occ30)
            maggiore=18;
        else
            maggiore=30;
        printf("PROCESSI TERMINATI. CONTROLLA FILE OUTPUT.TXT\n");
        fprintf(fd,"18 si ripete %d volte, 30 si ripete %d volte, quello con più occorrenze e' %d",occ18,occ30,maggiore);
        fclose(fd);
    //}
        
    }
    return 0;
}
