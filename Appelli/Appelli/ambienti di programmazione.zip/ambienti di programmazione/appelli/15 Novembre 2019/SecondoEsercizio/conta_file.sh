# conta_file.sh cartelle.txt
if [ ! -f $1 ];then
    echo "Il parametro deve essere una cartella!"
    exit -1
fi
if [ $# -ne 1 ];then
    echo "Parametri non validi! Esempio: $0 cartelle.txt"
    exit -1
fi
if [ -f RisultatoFile.txt ];then
    echo "Rimuovo file RisultatoFile.txt ..."
    rm RisultatoFile.txt
fi

    touch RisultatoFile.txt
    cartelle=$(cat $1)
    contaFile=0
    for i in $cartelle;do
        nFile=$(ls $i)
        for j in $nFile;do
            if [ -f $i/$j ];then
                let contaFile=contaFile+1
            fi
        done
        echo "Nella cartella $i ci sono $contaFile " >> RisultatoFile.txt
        contaFile=0
    done
