/* Realizzare un programma C che, utilizzando le System Call di Linux, conti le occorrenze del carattere ‘a’ nel file “lettera.txt”, contenente L caratteri, (si supponga L multiplo di 2).
Il processo principale dovrà creare una (o più) pipe e quindi 2 processi figli F1, F2. Il primo figlio conterà le occorrenze nella porzione di file dalla posizione 0 alla posizione L/2 – 1 e il secondo dalla posizione L/2 alla posizione L-1. Quindi i figli invieranno al padre i risultati parziali tramite la pipe e il genitore provvederà a calcolare il totale e stamperà in output: Il carattere a è presente n volte nel File Lettera.txt.
(Suggerimento: utilizzare lseek nel caso del secondo figlio per spostarsi di L/2 posizioni nel file.)
Sarà apprezzata la generalizzazione del problema a N figli, con L multiplo di N. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

void leggiA(char*,int,int,int*);

int main(){
    int pFiglioUno[2],pFiglioDue[2],pid,pos,lungFile,fd,status;
    fd=open("lettera.txt",O_RDONLY);
    if(fd==-1){
        printf("File non trovato.");
        exit(1);
    }
    lungFile=lseek(fd,0,SEEK_END);
    close(fd);
    if(pipe(pFiglioUno)==-1){
        printf("Errore durante la creazione della pipe.");
        exit(2);
    }
    if(pipe(pFiglioDue)==-1){
        printf("Errore durante la creazione della pipe.");
        exit(2);
    }
    pos=0;
    pid=fork();
    if(pid>0){
        pos=1;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore durante la creazione del processo.");
        exit(3);
    }
    if(pid==0){
        if(pos){//figlio1
            leggiA("lettera.txt",0,(lungFile/2)-1,pFiglioUno);
        } else {//figlio2
            leggiA("lettera.txt",lungFile/2,lungFile-1,pFiglioDue);
        }
    } else {//padre
        int occ=0,occTot=0;
        wait(&status);
        wait(&status);
        read(pFiglioUno[0],&occ,sizeof(int));
        occTot=occTot+occ;
        read(pFiglioDue[0],&occ,sizeof(int));
        occTot=occTot+occ;
        printf("La lettera a si ripete %d volte.",occTot);
    }
    return 0;
}

void leggiA(char nomeFile[100],int inizio,int fine,int* buffer){
    int i,occ=0,fd;
    char lettera;
    fd=open("lettera.txt",O_RDONLY);
    if(fd==-1){
        printf("Errore nella ricerca del file.");
        exit(1);
    }
    lseek(fd,inizio,SEEK_SET);
    for(i=inizio;i<fine;i++){
        read(fd,&lettera,1);
        if(lettera=='a')
            occ++;
    }
    close(fd);
    write(buffer[1],&occ,sizeof(int));
    exit(2);
}
