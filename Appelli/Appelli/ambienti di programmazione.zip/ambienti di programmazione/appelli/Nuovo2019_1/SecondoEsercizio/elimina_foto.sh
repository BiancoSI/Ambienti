#Scrivere un programma shell (elimina_foto.sh) che riceva 3 parametri, i primi due sono i nomi di estensioni di foto (esempio jpg, gif), il terzo è il nome di una cartella (esempio cart_foto). Esempio d’uso sarà quindi: elimina_foto.sh jpg gif cart_foto. Il programma dovrà eliminare tutte le foto (contenute nella cartella cart_foto) con estensione  jpg per le quali non esiste il corrispondente file gif (esempio: se nella cartella sono presenti i file:   a.jpg  b.jpg c.jpg d.jpg e.jpg    a.gif c.gif e.gif, dovranno essere eliminati i file b.jpg d.jpg).
#Alla fine il programma dovrà stampare il numero di file eliminati e il numero di jpeg rimanenti. Gestire anche il controllo degli errori (parametri insufficienti, file di output già esistente, cartella inesistente, ecc..).

if [ $# -ne 3 ];then
    echo "Devi inserire 3 valori! Esempio: jpg gif cart_foto."
fi
if [ ! -d $3 ];then
    echo "Il terzo valore deve essere una cartella! Esempio: jpg gif cart_foto."
else
    file=$(ls $3)
    fileEliminati=0
    fileRestanti=0
    tempFile=''
    for i in $file;do
        tempFile=$( echo -n $i | sed -s "s/$1/$2/" )
        if [ ! -f $3/$tempFile ];then
            rm $3/$i
            let fileEliminati=fileEliminati+1
        else
            let fileRestanti=fileRestanti+1
        fi
    done
    echo "File restanti= $fileRestanti e file eliminati=$fileEliminati"
fi

