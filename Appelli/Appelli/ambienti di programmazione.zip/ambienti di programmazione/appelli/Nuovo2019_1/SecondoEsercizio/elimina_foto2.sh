if [ $# -ne 3 ];then
    echo "Stringa scorretta ! Esempio: jpg gif cart_foto"
    exit -1
fi
if [ ! -d $3 ];then
    echo "Stringa scorretta ! Esempio: jpg gif cart_foto"
    exit -1
else

    fileRestanti=0
    fileEliminati=0
    tmp=''
    file=$(ls $3)
    cd $3
    ls
    for i in $file;do
        temp=$(echo -n $i | sed -s "s/$1/$2/")
        if [ ! -f $temp ];then
            rm $i
            let fileEliminati=fileEliminati+1
        else
            let fileRimanenti=fileRimanenti+1
        fi
    done
    echo "Sono rimasti $fileRimanenti ed eliminati $fileEliminati"
fi
