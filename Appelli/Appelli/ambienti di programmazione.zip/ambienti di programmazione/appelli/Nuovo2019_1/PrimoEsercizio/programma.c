/* Scrivere un programma in C per la gestione di matrici di float, che contenga i seguenti metodi:
Una funzione create, che riceve due interi (dimensione di righe e colonne), crea una matrice delle dimensioni indicate, e restituisce il suo puntatore.
Un metodo read per la lettura di una matrice da tastiera.
Un metodo print per la stampa della matrice su output.
Un metodo trova_proprietà che restituisce (in maniera opportuna usando i puntatori) il numero di righe che soddisfino la seguente proprietà (e inoltre restituisce true se la proprietà è verificata almeno una volta, false se non è mai verificata):
	Una riga verifica la proprietà se esiste un elemento X non appartenente a quella riga per cui la somma degli elementi della riga   è uguale a X * 5.
Il metodo main che dichiara e alloca la matrice e invoca opportunamente i metodi precedenti. */

#include <stdio.h>
#include <stdlib.h>

typedef enum{false,true} bool;

float** create();
float** read(float**,int,int);
void print(float**,int,int);
bool trovaProprieta(float**,int,int,int*);

int main(){
    float **m;
    int rig,col,righeOk=0;
    printf("Inserisci numero righe:");
    scanf("%d",&rig);
    printf("Inserisci numero colonne:");
    scanf("%d",&col);
    m=create(rig,col); 
    m=read(m,rig,col);
    print(m,rig,col);
    if(trovaProprieta(m,rig,col,&righeOk))
        printf("Sono state trovare %d righe che soddisfino la proprietà.\n",righeOk);
    else
        printf("Non sono state trovare righe che soddisfino la proprietà.\n");
    printf("%d",righeOk);
    return 0;
}

bool trovaProprieta(float** m,int rig,int col,int* righeOk){
    int i,j,k,l;
    float somma;
    bool trova=false;
    for(i=0;i<rig;i++){ 
        for(j=0;j<col;j++){
            for(k=0;k<rig;k++){
                if(i!=k){
                    for(l=0;l<col;l++){
                        somma=somma+m[k][l];
                    }
                    if(somma==( m[i][j] *5)){
                        trova=true;
                        *righeOk=*righeOk+1;
                    }
                somma=0;
                }
            }
        }
    }
}

float** create(int rig,int col){
    int i;
    float **m;
    m=(float**)malloc(rig*sizeof(float*));
    if(m==NULL){
        printf("Memoria non disponibile.");
        exit(2);
    }
    for(i=0;i<rig;i++){
            m[i]=(float*)malloc(col*sizeof(float));
            if(m[i]==NULL){
                printf("Memoria non disponibile.");
                free(m);
                exit(2);
        }
    }
    return m;
}

float** read(float** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("Inserisci il numero nella riga %d e colonna %d: ",i,j);
            scanf("%f",&m[i][j]);
        }
    }
    return m;
}

void print(float** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++)
            printf("%f ",m[i][j]);
        printf("\n");
    }
}
