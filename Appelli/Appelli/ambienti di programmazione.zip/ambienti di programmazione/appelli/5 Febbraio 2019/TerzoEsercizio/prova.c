#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

int main(){
    int a=1,b=2,c=3,i;
    char scrivi[100]="Ciao %d %d %d";
    int fd=open("prova.txt",O_WRONLY);
    lseek(fd,0,SEEK_SET);
    write(fd,&scrivi,100);
    /*char lettera;
    for(i=0;i<100;i++){
        lettera=scrivi[i];
        write(fd,&lettera,1);
    }*/
    close(fd);
    }
