/* Realizzare un programma C che, utilizzando le System Call di Linux, svolga le seguenti operazioni. Il padre, prima crea 3 figli, poi legge da un file binario “Input” una serie di interi, uno alla volta. Quindi comunica i numeri <10 al primo figlio, i maggiori di 30 al secondo figlio e quelli compresi fra 10 e 30 al terzo figlio. I tre figli trovano la media dei numeri ricevuti, li ritornano al padre che stamperà su un file di testo output.txt, ordinati per figlio le rispettive medie (esempio: Il primo figlio ha trovato la media 34.5, il secondo figlio…) */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

void contaMedia(int* buffer,int somma){
    int totNumeri,ciclo=1,num;
    while(ciclo){
        read(buffer[0],&num,sizeof(int));
        if(num!=0){
            somma=somma+num;
            totNumeri++;
        } else
            ciclo=num;
    }
    somma=somma/totNumeri;
    write(buffer[1],&somma,sizeof(int));
    exit(2);
}

int main(){
    printf("Sono qua");
    int pid,pFiglio1[2],pFiglio2[2],pFiglio3[2],nFigli=3,pos,status,i;
    if(pipe(pFiglio1)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    if(pipe(pFiglio2)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    if(pipe(pFiglio3)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    pid=fork();
    pos=0;
    if(pid>0){
        pid=fork();
        pos=1;
        if(pid>0){
            pid=fork();
            pos=2;
        }
    }
    if(pid==-1){
        printf("Errore nella creazione del processo.");
        exit(2);
    }
    if(pid==0){
        if(pos==0)
            contaMedia(pFiglio1,0);
        if(pos==1)
            contaMedia(pFiglio2,0);
        if(pos==2)
            contaMedia(pFiglio3,0);
    } else {
    int fd,lungFile,num;
    fd=open("input",O_RDONLY);
    lungFile=lseek(fd,0,SEEK_END);
    lseek(fd,0,SEEK_SET);
    for(i=0;i<lungFile;i++){
        read(fd,&num,sizeof(int));
        if(num<10)
            write(pFiglio1[1],&num,sizeof(int));
        if(num>30)
            write(pFiglio2[1],&num,sizeof(int));
        if(num>10 && num<30)
            write(pFiglio3[1],&num,sizeof(int));
    }//caso in cui lo 0 indica la fine dei numeri
    num=0;
    close(fd);
    write(pFiglio1[1],&num,sizeof(int));
    write(pFiglio2[1],&num,sizeof(int));
    write(pFiglio3[1],&num,sizeof(int));
    wait(&status);
    wait(&status);
    wait(&status);
    int figlio1,figlio2,figlio3;
    read(pFiglio1[0],&figlio1,sizeof(int));
    read(pFiglio2[0],&figlio2,sizeof(int));
    read(pFiglio3[0],&figlio3,sizeof(int));
    printf("primo %d, secondo %d, terzo %d ",figlio1,figlio2,figlio3);
    return 0;
    }
}
