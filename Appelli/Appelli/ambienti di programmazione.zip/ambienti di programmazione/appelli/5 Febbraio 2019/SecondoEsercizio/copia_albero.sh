#Scrivere un programma shell (copia_albero.sh) che riceva come parametri due cartelle e copia tutte le cartelle e sottocartelle fino al secondo livello dalla prima cartella alla seconda cartella. Ricreerà quindi lo stesso albero delle directory, con un’unica eccezione, se trova un file con estensione .exe, deve cambiare la sua estensione in .sh 
#Esempio d’uso sarà : copia_albero.sh cartella_sorgente cartella_destinazione.
#Gestire anche il controllo degli errori (parametri insufficienti, file di output già esistente, cartella inesistente, ecc..).
#Esempio: copia_albero.sh Build1 BuildPackage  (nella figura non sono visualizzati i file per semplicità)

if [ ! -d $1 ];then
    echo "Parametri non validi. Esempio: copia_albero.sh Build1 BuildPackage"
    exit -1
fi
if [ ! -d $2 ];then
    echo "Parametri non validi. Esempio: copia_albero.sh Build1 BuildPackage"
    exit -1
fi
if [ $# -ne 2 ];then
    echo "Parametri non validi. Esempio: copia_albero.sh Build1 BuildPackage"
else
    liv1=$(ls $1)
    temp=''
    for i in $liv1;do
        if [ -f $1/$i ];then
            temp=$(echo -n $i|sed -s 's/.exe/.sh/')
            touch $2/$temp
        else
            mkdir $2/$i
            livello2=$(ls $1/$i)
            for j in $livello2;do
                if [ -f $1/$i/$j ];then
                    temp=$(echo -n $j|sed -s 's/.exe/.sh/')
                    touch $2/$i/$temp
                else
                    mkdir $2/$i/$j
                fi
            done
        fi
    done
fi
