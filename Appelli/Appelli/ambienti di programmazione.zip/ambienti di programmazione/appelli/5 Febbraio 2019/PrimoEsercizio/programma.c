/* Scrivere un programma in C per la gestione di matrici di interi, che contenga i seguenti metodi:
Una funzione create, che riceve due interi (dimensione di righe e colonne), crea una matrice delle dimensioni indicate, e restituisce il suo puntatore.
Un metodo read per la lettura di una matrice da tastiera.
Un metodo print per la stampa della matrice su output.
Un metodo verifica_vet_matrice, a cui viene passato fra gli altri parametri anche un vettore V di interi, e che restituisce (in maniera opportuna usando i puntatori) 2 interi, matVerPos e vetVerNeg:
il primo (matVerPos) corrisponde al numero di colonne che verifichino la seguente proprietà: il numero di elementi positivi in posizione pari della colonna è maggiore del numero di elementi negativi in posizione dispari.
il secondo (vetVerNeg) è il numero di righe della matrice in cui almeno un terzo degli elementi negativi siano  maggiori del corrispondente elemento del vettore V (si suppone che la dimensione di V è pari al numero di colonne della matrice). 
Il metodo main che dichiara e alloca la matrice e invoca opportunamente i metodi precedenti. */
#include <stdlib.h>
#include <stdio.h>


int** create(int,int);
int** read(int**,int,int);
void print(int**,int,int);
void verifica_vet_matrice(int**,int,int,int*,int*,int*);
int* riempiV(int*,int);

int main(){
    int **m,rig,col,matVerPos,vetVerNeg;
    printf("Inserisci numero di righe della matrice: ");
    scanf("%d",&rig);
    printf("Inserisci numero delle colonne della matrice: ");
    scanf("%d",&col);
    m=create(rig,col);
    m=read(m,rig,col);
    print(m,rig,col);
    matVerPos=0;
    vetVerNeg=0;
    int *V;
    V=riempiV(V,col);
    verifica_vet_matrice(m,rig,col,&matVerPos,&vetVerNeg,V);
    printf("MatVerPos %d \n",matVerPos);
    printf("VetVerNeg %d \n",vetVerNeg);
    return 0;
}

void verifica_vet_matrice(int** m,int rig,int col,int* matVerPos,int* vetVerNeg,int* v){
    int i,j,sommaPari=0,sommaDispari=0;
    for(j=0;j<col;j++){
        for(i=0;i<rig;i++){
            if(j%2==0 && m[i][j]%2==0){
                sommaPari++;
            }
            if(j%2!=0 && m[i][j]%2!=0){
                sommaDispari++;
            }
        }
        if(sommaPari>sommaDispari)
            *matVerPos=*matVerPos+1;
        sommaPari=0;
        sommaDispari=0;
    }
    int contaTotNegativi=0,contaTotOk=0; //contaTotNegativi conta tutti i negativi della riga mentre contaTotOk conta quali soddisfano la condizione (elemento matrice)>(elemento vettore)
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            if(m[i][j]<0){
                contaTotNegativi++;
                if(m[i][j]>v[j])
                    contaTotOk++;
            }
        }
        if(contaTotOk>(contaTotNegativi/3))
            *vetVerNeg=*vetVerNeg+1;
        contaTotNegativi=0;
        contaTotOk=0;
    }
}

int* riempiV(int* v,int rig){
    int i;
    for(i=0;i<rig;i++)
        v[i]=-4;
    return v;
}

int** create(int rig,int col){
    int **m,i;
    m=(int**)malloc(rig*sizeof(int*));
    if(m==NULL){
        printf("Memoria non disponibile.");
        exit(2);
    }
    for(i=0;i<rig;i++){
        m[i]=(int*)malloc(col*sizeof(int));
        if(m[i]==NULL){
            printf("Memoria non disponibile");
            free(m);
            exit(1);
            }
    }
    return m;
}

int** read(int** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("Inserisci il numero da inserire nella matrice riga %d colonna %d: ",i,j);
            scanf("%d",&m[i][j]);
        }
    }
    return m;
}

void print(int** m,int rig,int col){
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++)
            printf("%d ",m[i][j]);
        printf("\n");
    }
}
