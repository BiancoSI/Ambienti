/* Realizzare un programma C che, utilizzando le System Call di Linux, sommi i numeri in valore assoluto < 15 e quelli maggiori  uguale a 15 contenuti nel file “Numeri.dat”, contenente k numeri interi.
Il processo principale dovrà creare due pipe e quindi 2 processi figli Fa e Fb. Il padre leggerà un numero dal file “Dati” e, se è minore in valore assoluto di 15, lo scriverà sulla pipe che lo collega a Fa, altrimenti lo manderà a Fb. Tutto ciò sarà ripetuto fino alla fine del file, quindi il padre manderà un numero speciale (magari 0) per indicare ai figli che non ci sono più numeri. 
Fa sommerà tutti numeri ricevuti dal padre e scriverà il risultato all’inizio del file “posA”, già esistente.  Fb farà lo stesso e lo scriverà alla fine del file “posB”.
(Suggerimento: utilizzare lseek per posizionarsi all’inizio o alla fine del file prima di scrivervi i risultati.) */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

void scriviRisultato(int* buffer,char nomeFile[100]){
    int fd,ciclo,numero,somma;
    ciclo=1;
    somma=0;
    while(ciclo){
        read(buffer[0],&numero,sizeof(int));
        if(numero!=0)
            somma=somma+numero;
        else
            ciclo=numero;    
    }
    fd=open(nomeFile,O_WRONLY);
    if(fd==-1){
        printf("Errore durante l'apertura del file %s .",nomeFile);
        exit(29);
    }
    lseek(fd,0,SEEK_SET);
    
    write(fd,&somma,sizeof(int));
    close(fd);
    
}
    

int main(){
    int pFiglioA[2],pFiglioB[2],pid,pos,status,fd,lungFile,i;
    
    pos=1;
    if(pipe(pFiglioA)==-1){
        printf("Errore durante la creazione della pipe.");
        exit(1);
    }
    if(pipe(pFiglioB)==-1){
        printf("Errore durante la creazione della pipe.");
        exit(1);
    }
    pid=fork();
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore durante la creazione del processo.");
        exit(2);
    }
    if(pid==0){  
        if(pos)//figlio1
            scriviRisultato(pFiglioA,"posA");
        else //figlio 2
            scriviRisultato(pFiglioB,"posB");
    }
    else {
    //padre
    fd=open("Numeri.dat",O_RDONLY);
    if(fd==-1){
        printf("Errore durante l'apertura del file Numeri.dat .");
        exit(29);
    }
    lungFile=lseek(fd,0,SEEK_END);
    lseek(fd,0,SEEK_SET);
    char numeroChar;
    int numeroIntero=0;
    int c=1;
    int temp=0;
    int segno=0;
    for(i=0;i<lungFile;i++){
        read(fd,&numeroChar,1);
        if(numeroChar!=' '){
            if(numeroChar=='-')
                segno=1;
            else{
                numeroIntero=numeroIntero*c;
                temp=numeroChar-'0';
                //printf("%d ",numeroIntero);
                numeroIntero=numeroIntero+temp;
                c=c*10;
                //printf("%d ",numeroIntero);
            }
        } //else {
        if(numeroChar==' ' || (lungFile==i+1 && numeroChar!=' ')){
            printf("%d ",numeroIntero);
            if(segno)
                numeroIntero=numeroIntero-(numeroIntero*2);
            if( (numeroIntero<=15) && (numeroIntero>=-15) )
                write(pFiglioA[1],&numeroIntero,sizeof(int));
            else
                write(pFiglioB[1],&numeroIntero,sizeof(int)); 
            c=1;
            numeroIntero=0;
            segno=0;
        }
    }
    close(fd);
    numeroIntero=0;
    write(pFiglioB[1],&numeroIntero,sizeof(int));
    write(pFiglioA[1],&numeroIntero,sizeof(int));
    wait(&status);
    wait(&status);
    }
}
