/* Realizzare un programma C che, utilizzando le System Call di Linux, sommi i numeri in valore assoluto < 15 e quelli maggiori  uguale a 15 contenuti nel file “Numeri.dat”, contenente k numeri interi.
Il processo principale dovrà creare due pipe e quindi 2 processi figli Fa e Fb. Il padre leggerà un numero dal file “Dati” e, se è minore in valore assoluto di 15, lo scriverà sulla pipe che lo collega a Fa, altrimenti lo manderà a Fb. Tutto ciò sarà ripetuto fino alla fine del file, quindi il padre manderà un numero speciale (magari 0) per indicare ai figli che non ci sono più numeri. 
Fa sommerà tutti numeri ricevuti dal padre e scriverà il risultato all’inizio del file “posA”, già esistente.  Fb farà lo stesso e lo scriverà alla fine del file “posB”.
(Suggerimento: utilizzare lseek per posizionarsi all’inizio o alla fine del file prima di scrivervi i risultati.) */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

void scriviRisultato(int* buffer,char nomeFile[100]){
    int ciclo,numero,sommaNumeri,fd;
    ciclo=1;
    sommaNumeri=0;
    while (ciclo){
        read(buffer[0],&numero,sizeof(int));
        if(numero!=0)
            sommaNumeri=sommaNumeri+numero;
        else
            ciclo=numero;
    }
    fd=open(nomeFile,O_WRONLY);
    if(fd==-1){
        printf("Errore durante l'apertura del file.");
        exit(2);
    }
    lseek(fd,0,SEEK_END);
    //printf("%d ",sommaNumeri);
    write(fd,&sommaNumeri,sizeof(int));
    close(fd);
}

int main() {

    int pid,pos,pFiglioA[2],pFiglioB[2],fd,lungFile,status;
    pos=1;
    if(pipe(pFiglioA)==-1){
        printf("Errore durante la creazione della pipe del figlio A.");
        exit(2);
    }
    if(pipe(pFiglioB)==-1){
        printf("Errore durante la creazione della pipe del figlio B.");
        exit(2);
    }
    fd=open("Numeri.dat",O_RDONLY);
    if(fd==-1){
        printf("Errore durante la lettura del file.");
        exit(2);
    }
    lungFile=lseek(fd,0,SEEK_END);
    close(fd);
    pid=fork();
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore durante la creazione del padre.");
        exit(1);
    }
    if(pid==0){
        if(pos){//figlioA
            scriviRisultato(pFiglioA,"posA");
            exit(2);
        } else { //figlioB
            scriviRisultato(pFiglioB,"posB");
            exit(2);
        }
    } else { //padre
        fd=open("Numeri.dat",O_RDONLY);
        lseek(fd,0,SEEK_SET);
        int i,segno,temp,numeroIntero,c;
        segno=0;
        c=1;
        numeroIntero=0;
        char numeroChar;
        for(i=0;i<lungFile;i++){
        read(fd,&numeroChar,1);
        if(numeroChar==' '||numeroChar==-1||numeroChar==10){
          if(numeroIntero!=0){
            if(segno){
                numeroIntero=(-numeroIntero);
            }
            printf("%d ",numeroIntero);
            if( (numeroIntero<=15) && (numeroIntero>=-15) )
                write(pFiglioA[1],&numeroIntero,sizeof(int));
            else
                write(pFiglioB[1],&numeroIntero,sizeof(int));
            c=1;
            numeroIntero=0;
            segno=0;
          }
        } else {
            if(numeroChar=='-')
                segno=1;
            else{
                numeroIntero=numeroIntero*c;
                temp=numeroChar-'0';
                //printf("%d ",numeroIntero);
                numeroIntero=numeroIntero+temp;
                c=c*10;
                //printf("%d ",numeroIntero);
            }
        }
    }
        close(fd);
        c=0;
        write(pFiglioA[1],&c,sizeof(int));
        write(pFiglioB[1],&c,sizeof(int));
        wait(&status);
        wait(&status);
    }
    return 0;
}
