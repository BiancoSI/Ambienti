#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>

int main(){
    char buffer[]="abcdefghilmnopqrstuvz";
    int fd;
    fd=creat("lettere_scrivo.txt",0777);
    write(fd,buffer,24);
    close(fd);
}
