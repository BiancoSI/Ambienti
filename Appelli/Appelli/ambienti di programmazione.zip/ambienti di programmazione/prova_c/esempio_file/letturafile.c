#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>

int main(){
    int fd;
    char newbuffer[100];
    fd=open("lettere.txt",O_RDONLY);
    read(fd,newbuffer,24);
    printf("Lettura file: %s",newbuffer);
    close(fd);
}
