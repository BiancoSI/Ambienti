/*Realizzare un programma C che, utilizzando le System Call di Linux, e conti  le occorrenze del voto 30 ed del voto 18
 in un file binario ‘voti’. Il processo principale dovrà creare una (o più) pipe e quindi 2 processi figli F18 e F30.  Quindi dovrà leggere al file i voti e se il voto risulta essere 18, passarlo al figlio F18, mentre se il voto risulta F30 dovrà passarlo al figlio F30. Il primo figlio (F18) conterà le occorrenze del voto 18, il secondo conterà le occorrenze del voto 30 e poi entrambi 
ritorneranno il risultato al padre che li stamperà.(Suggerimento: utilizzare lseek per spostarsi nel file.) */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

#define NVOTI 11

int scriviFileRiceviLunghezza(char nomeFile[100],int* voti,int nvoti){
    int i,fd;
    printf("Creo/sovrascirov il file %s e visualizzo i voti ricevuti.",nomeFile);
    fd=open("voti",O_WRONLY|O_CREAT);
    if(fd==-1){
        printf("Errore nell'apertura del file.");
        exit(2);
    }
    for(i=0;i<nvoti;i++){
        write(fd,&voti[i],sizeof(int));
        printf("%d ",voti[i]);
    }
    printf("\n");
    int lungFile=lseek(fd,0,SEEK_END);
    close(fd);
    return lungFile;
}

void cercaNumeri(int* buffer){
    int occTot=0;
    int occ=1;   
    while(occ==1){
        read(buffer[0],&occ,sizeof(int));
        if(occ==1)
            occTot++;
    }
    write(buffer[1],&occTot,sizeof(int));
    exit(12);
}

int main(){
    int fd,pFiglio18[2],pFiglio30[2],pos,pid,status,i,lungFile;
    int voti[]={18,30,20,25,6,18,18,30,2,19,29};
    lungFile=scriviFileRiceviLunghezza("voti",voti,NVOTI);
    pos=1;
    if(pipe(pFiglio18)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    if(pipe(pFiglio30)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    pid=fork();
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore nella creazione del processo.");
        exit(1);
    } if (pid==0) {
        if(pos){ //figlio1
            cercaNumeri(pFiglio18);
        } else { //figlio 2
            cercaNumeri(pFiglio30);
        }
    } else { //padre
        int occ=1;
        printf("%d",lungFile);
        for(i=0;i<lungFile;i++){
            if(voti[i]==18)
                write(pFiglio18[1],&occ,sizeof(int));
            if(voti[i]==30)
                write(pFiglio30[1],&occ,sizeof(int));
        }
        occ=0;
        write(pFiglio18[1],&occ,sizeof(int));
        write(pFiglio30[1],&occ,sizeof(int));
        wait(&status);
        wait(&status);
        int volte18,volte30;
        read(pFiglio18[0],&volte18,sizeof(int));
        read(pFiglio30[0],&volte30,sizeof(int));
        printf("Il numero 18 di ripete %d volte ed il numero 30 si ripete %d volte. \n",volte18,volte30);
    }

}
    
