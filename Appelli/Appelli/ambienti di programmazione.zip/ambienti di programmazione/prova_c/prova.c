#include <stdio.h>

main(int argc, char *argv[])
   
  {
    int pid;
     printf ("ciao a tutti\n");
     pid = fork();
     printf("arrivederci a tutti\n");
	 }
