#include <stdio.h>
#include <stdlib.h>

void trovaNumero(int,int,int,int*,int*,int**);

int main(){
    int rig=3,col=3,i,**m,j,num,rigNum,colNum;
    m=(int**)malloc(rig*sizeof(int*));
    if(m==NULL){
        printf("memoria non disponibile.");
        exit(2);
    }
    for(i=0;i<rig;i++){
        m[i]=(int*)malloc(col*sizeof(int));
        if(m[i]==NULL){
            printf("Memoria non disponibile");
            exit(1);
        }
    }
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("Inserisci numero matrice nella riga %d e colonna %d: ",i,j);
            scanf("%d",&m[i][j]);
        }
        printf("\n");
    }
    printf("Visualizzo a video matrice. \n");
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            printf("%d ",m[i][j]);
        }
        printf("\n");
    }
    printf("Quale numero vuoi trovare ?:");
    scanf("%d",&num);
    trovaNumero(num,rig,col,&rigNum,&colNum,m);
    if(rigNum==-1)
        printf("Spiacenti, il numero %d non è stato trovato",num);
    else
        printf("Il numero %d è stato trovato nella riga %d e colonna %d .",num,rigNum,colNum);
}

void trovaNumero(int num,int rig,int col,int* rigNum,int* colNum,int** m){
    *rigNum=-1;
    *colNum=-1;
    int i,j;
    for(i=0;i<rig;i++){
        for(j=0;j<col;j++){
            if(m[i][i]==num){
                *rigNum=i;
                *colNum=j;
            }
        }
    }
}
