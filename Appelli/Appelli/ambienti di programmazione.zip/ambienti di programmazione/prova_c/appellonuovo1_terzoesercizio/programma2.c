/* Il programma conta il numero di 'a' presenti nel file lettera.txt. I due figli divideranno i compiti, uno la prima meta e l'altro la seconda meta. Il padre ha il compito di far visualizzare a video
il numero delle a.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>

void calcolaA(int inizio,int fine,int occ,int* buffer){
    int i;
    char lettera;
    
    int fd=open("lettera.txt",O_RDONLY);
    lseek(fd,inizio,SEEK_SET);
    for(i=inizio;i<fine;i++){
        read(fd,&lettera,1);
        if(lettera=='a')
            occ++;
    }
    write(buffer[1],&occ,sizeof(int));
    close(fd);
}

int main(){
    int pid,status,fd,lungFile,primaMeta[2],secondaMeta[2];
    int pos=1;
    int occ=0;
    fd=open("lettera.txt",O_RDONLY);
    lungFile=lseek(fd,0,SEEK_END);
    //printf("%d",lungFile);
    close(fd);
    if(pipe(primaMeta)==-1){
        printf("Errore durante la creazione della pipe.");
        exit(2);
    }
    if(pipe(secondaMeta)==-1){
        printf("Errore durante la creazione della pipe.");
        exit(2);
    }
    pid=fork();
    if(pid>0){
        pid=fork();
        pos=0;
    }
    if(pid==-1){
        printf("Errore nella creazione del processo.");
        exit(1);
    }
    if (pid==0) {
    //FIGLI
        if(pos){
            //figlio sinistro
            calcolaA(0,(lungFile/2),occ,primaMeta);
            exit(2);
        } else {
            //figlio destro
            calcolaA((lungFile/2)+1,lungFile,occ,secondaMeta);
            exit(2);
        }
    } else {
    //PADRE
        int occTot=0;
        wait(&status);
        wait(&status);
        read(primaMeta[0],&occ,sizeof(int));
        occTot=occTot+occ;
        read(secondaMeta[0],&occ,sizeof(int));
        occTot=occTot+occ;
        printf("La lettera 'a' si ripete %d volte.\n",occTot);
    }
}
