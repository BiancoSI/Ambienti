#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>

int main(){

    int pFiglioUno[2],pFiglioDue[2],fd,pid,status,lung,i;
    char lettera;
    int pos=1;
    int occ=0;
    //CALCOLO LUNGHEZZA FILE
    fd=open("lettera.txt",O_RDONLY);
    lung=lseek(fd,0,SEEK_END);
    close(fd);
    if(pipe(pFiglioUno)==-1){
        printf("Errore nella creazione della pipe");
        exit(2);
    }
    if(pipe(pFiglioDue)==-1){
        printf("Errore nella creazione della pipe");
        exit(2);
    }
    pid=fork();
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1){
        printf("Errore durante la creazione del processo.");
        exit(1);
    }
    if(pid==0){
        if(pos){// FIGLIO META' SINISTRA
            fd=open("lettera.txt",O_RDONLY);
            lseek(fd,0,SEEK_SET);
            for(i=0;i<lung/2;i++){
                read(fd,&lettera,1);
                if(lettera=='a')
                    occ=occ+1;
            }
            close(fd);
            write(pFiglioUno[1],&occ,sizeof(int));
        } else {
        //FIGLIO META' DESTRA
            fd=open("lettera.txt",O_RDONLY);
            lseek(fd,(lung/2),SEEK_SET);
            for(i=(lung/2);i<lung;i++){
                read(fd,&lettera,1);
                if(lettera=='a')
                    occ=occ+1;
            }
            close(fd);
            write(pFiglioDue[1],&occ,sizeof(int));
        }
    }
    else {
        //PADRE
        printf("Sono qua");
        wait(&status);
        wait(&status);
        int occTotale=0;
        read(pFiglioUno[0],&occ,sizeof(int));
        occTotale=occTotale+occ;
        read(pFiglioDue[0],&occ,sizeof(int));
        occTotale=occTotale+occ;
        printf("La lettera 'a' si ripete %d volte nel file.",occTotale);
    }
}
