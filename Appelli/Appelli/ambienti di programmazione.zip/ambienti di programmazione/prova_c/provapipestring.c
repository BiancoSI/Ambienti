#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(){
    int pp[2],i,pid,status;
    char buffer[100];
    char messaggio[100];
    if(pipe(pp)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    pid=fork();
    if(pid==-1){
        printf("Errore durante la creazione del processo.");
        exit(1);
    }
    if(pid==0){
    //FIGLIO
        read(pp[0],buffer,sizeof(buffer));
        printf("Sono il figlio, ho %d pid. \n",getpid());
        printf("Messaggio ricevuto: %s \n",buffer);
    }
    else {
    //PADRE
        printf("Inserisci il messaggio da inviare:");
        scanf("%s",&messaggio);
        write(pp[1],messaggio,sizeof(messaggio));
        wait(&status);
        printf("Mio figlio con %d ha terminato la sua esecuzione. \n",pid);
    }
}
