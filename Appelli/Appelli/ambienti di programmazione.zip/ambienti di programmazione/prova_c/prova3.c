/* esempio di wait e di exit */
#include <stdio.h>

main(int argc, char *argv[])
   
  {
     int pid, status;

     pid = fork();
     if (pid==-1) 
          printf ("Errore nella creazione del processo"); 
     else if (pid==0)
       {
        int i;
        for (i=0;i<10;i++)
           printf ("Sono il figlio\n");
        exit (2);
        }
     else
        {
          printf ("aspetto mio figlio\n");
          wait (&status);
          printf ("Mio figlio ha terminato l'esecuzione\n");
           }
 }
