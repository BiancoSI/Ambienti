#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(){
    int pp[2],i,buffer[5],pid,status;
    int numeri[]={10,20,30,40,50};
    if(pipe(pp)==-1){
        printf("Errore nella creazione della pipe.");
        exit(2);
    }
    pid=fork();
    if(pid==-1){
        printf("Errore durante la creazione del processo.");
        exit(1);
    }
    if(pid==0){
    //FIGLIO
        printf("Sono il figlio, ho %d pid. \n Mio padre mi ha mandato questo:",getpid());
        read(pp[0],buffer,sizeof(int)*5);
        for(i=0;i<5;i++)
            printf("%d ",buffer[i]);
        printf("\n");
    }
    else {
    //PADRE
        printf("Sono il padre con %d pid, aspetto che mio figlio esegua le istruzioni. \n",getpid());
        write(pp[1],numeri,sizeof(int)*5);
        wait(&status);
        printf("Mio figlio con %d ha terminato la sua esecuzione. \n",pid);
    }
}
