/*Es. svolto: Scrivere un programma che gestisce il comportamento di un padre e due figli 
(Fpos e Fneg);il padre scorre un vettore. Se trova un numero positivo lo manda al figlio Fpos, 
altrimenti lo manda al figlio Fneg. 
I figli contano le occorrenze, quindi rimandano al padre che le stampa su output*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
    int pipePositivo[2],pipeNegativo[2],pid,status,i,numero;
    int pos=1;
    int occ=0;
    int ciclo=1;
    int n=10;
    int vett[10];

    if(pipe(pipePositivo)==-1){
        printf("Errore nella creazione delle pipe!");
    }
    if(pipe(pipeNegativo)==-1){
        printf("Errore nella creazione delle pipe!");
    }
    pid=fork();
    if(pid>0){
        pos=0;
        pid=fork();
    }
    if(pid==-1)
        printf("Errore nella creazione del processo.");
    if(pid==0){
        if(pos){//positivo
            while(ciclo){
                read(pipePositivo[0],&numero,sizeof(int));
                if(numero!=0)
                    occ=occ+1;
                else
                    ciclo=0;
            }
            write(pipePositivo[1],&occ,sizeof(int));
        }
        else{ //negativo
            while(ciclo){
                read(pipeNegativo[0],&numero,sizeof(int));
                if(numero!=0)
                    occ=occ+1;
                else
                    ciclo=0;
            }
            write(pipeNegativo[1],&occ,sizeof(int));
        }
    } else {
    //PADRE
    printf("Sono il padre, devi inserire %d valori nel vettore.",n);
    for(i=0;i<n;i++)
        scanf("%d",&vett[i]);
    for(i=0;i<n;i++)
        if(vett[i]>0)
            write(pipePositivo[1],&vett[i],sizeof(int));
        else
            write(pipeNegativo[1],&vett[i],sizeof(int));
    numero=0;//indica tappo per concludere.
    write(pipePositivo[1],&numero,sizeof(int));
    write(pipeNegativo[1],&numero,sizeof(int));
    wait(&status);
    wait(&status);
    read(pipePositivo[0],&numero,sizeof(int));
    printf("\nNumeri positivi: %d",numero);
    read(pipeNegativo[0],&numero,sizeof(int));
    printf("\nNumeri negativi: %d",numero);
    }
}
