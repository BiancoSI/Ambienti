#include <stdio.h>

main()
   
  {
     int pid;

     pid = fork();
     if (pid==-1) 
          printf ("Errore nella creazione del processo"); 
     else if (pid==0)
        printf ("Arrivederci a tutti,sono il figlio pid %d\n",pid); 
     else
         printf ("Arrivederci a tutti,sono il padre: il pid di mio figlio  e' %d\n",pid); 
 }
