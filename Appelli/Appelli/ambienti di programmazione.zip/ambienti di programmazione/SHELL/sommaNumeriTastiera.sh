echo "Scrivi un numero"; read x;
a=5;
let z=$a+$x
echo "Operazione: $a + $x = $z";
echo "Concatenare: $a$x";
echo "$HOSTNAME e $0";
