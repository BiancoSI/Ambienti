echo "Voto POO:"
read voto
case $voto in
    30) echo "Perfetto! Esame superato a pieni voti!"
    ;; 
    1[8-9]|2[0-9]) echo "Superato con successo!"
    ;;
    *) echo "Ritenta, sarai più fortunato"
    ;;
esac
