#appendi <parola> <file>
if [ $# -ne 2 ]; then
    echo "Elementi sbagliati !, devi inserire parola e nome file."
else
    echo "Quante volte devo inserire questa parola nel file ?"
    read volte
    parola=$1
    nomeFile=$2
    i=0
    echo "Inserirò la parola $parola, $volte volte nel file $nomeFile"
    while [ $i -lt $volte ]; do
        echo -n $parola >> $nomeFile
        echo -n " " >> $nomeFile
        let i=$i+1
    done
fi
