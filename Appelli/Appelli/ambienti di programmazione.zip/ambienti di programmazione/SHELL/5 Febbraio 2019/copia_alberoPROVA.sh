# copia_albero.sh Build1 BuildPackage

if [ ! -d $1 ];then
    echo "Directory non corretta ! Stringa corretta: copia_albero.sh Build1 BuildPackage"
    exit 2
fi
if [ ! -d $2 ];then
    echo "Directory non corretta ! Stringa corretta: copia_albero.sh Build1 BuildPackage"
    exit 2
fi
if [ $# -ne 2 ];then
    echo "Stringa non corretta! Esempio: copia_albero.sh Build1 BuildPackage"
    exit 1
else
    file=''
    livello1=$(ls $1)
    for i in $livello1;do
        if [ -f $1/$i/ ];then
            echo 'sono qui'
            file=$( echo -n $1/$i | sed 's/.exe/.sh/' )
            touch $2/$file
        else
            mkdir $2/$i
            livello2=$(ls $1/$i)
            for j in $livello2;do
                if [ -f $1/$i/$j ];then
                    echo 'sono qui'
                    file=$( echo -n $1/$i/$j | sed 's/.exe/.sh/' )
                    touch $2/$i/$file
                else
                    mkdir $2/$i/$j
                fi
            done
        fi
    done
fi
