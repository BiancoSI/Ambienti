if [ $# -lt 2 ]; then
    echo "DEVI INSERIRE ALMENO DUE ELEMENTI."
else
    echo "Hai lanciato il programma $0 con $# da sommare"
    somma=0
    for i in $@;do
        let somma=$somma+$i
    done
    echo "La somma di $@ è $somma"
fi
