doc=$(cat $1)
testo=$(echo $doc | sed 's/ambienti/Ciao, ambienti/')
echo $testo >> $1

#echo "ambienti di programmazione Ambienti AMBIENTI" | sed 's/ambienti/Ciao, ambienti/'
