#somma n numeri passati da riga di comando
if [ $# -lt 2 ]; then
	echo "devi inserire almeno 2 numeri da sommare"
else
echo "Stai lanciando $0 con $# numeri da sommare"
somma=0
for i in $@; do
	let somma=$somma+$i
done
echo "la somma dei numeri [ $@ ] e' uguale a $somma"


fi

