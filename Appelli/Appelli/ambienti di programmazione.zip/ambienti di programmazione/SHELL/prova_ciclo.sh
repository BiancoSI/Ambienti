i=0
while [ $i -lt 10 ]; do
    echo "ciao"
    let i=$i+1
done
for x in $(seq 10); do
    echo "ciao in for"
done
