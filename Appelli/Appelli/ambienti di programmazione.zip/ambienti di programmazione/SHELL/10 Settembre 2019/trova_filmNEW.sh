#trova_film.sh cart_film elenco_film.txt
#in elenco_film.txt : 'nomeFilm' 'anno' 'estensione'

if [ $# -ne 2 ];then
    echo "Parametri non validi. Esempio: trova_film.sh cart_film elenco_film.txt"
    exit -1
fi
if [ ! -d $1 ];then
    echo "Cartella non valida. Esempio: trova_film.sh cart_film elenco_film.txt"
    exit -1
fi
if [ -f output.txt ];then
    echo "File non deve esistere. Lo elimino."
    rm output.txt
else
    file=$(cat $2)
    count=0
    #cartellaFIlm=$(ls $1)
    nomeFilm=''
    anno=''
    estensione=''
    film=''
    touch output.txt
    for i in $file;do
        if [ $count -eq 0 ];then
            nomeFilm=$i
            let count=count+1
            continue
        fi
        if [ $count -eq 1 ];then
            anno=$i
            let count=count+1
            continue
        fi
        if [ $count -eq 2 ];then
            estensione=$i
            film=$nomeFilm'.'$estensione
            if [ -f $1/$anno/$film ];then
                echo "$film $anno giusto." >> output.txt
            else
                cartellaFilm=$(ls $1)
                for j in $cartellaFilm;do
                    if [ -f $1/$j/$film ];then
                        echo "Il film $film si trova nell'anno $j anzichè nel $anno" >> output.txt
                    fi
                done
            fi
            count=0
        fi
        

    done     

  
fi
