#trova_film.sh cartellaFilm elenco_nomi_film.sh

if [ ! -d $1 ];then
    echo 'Cartella non corretta ! Esempio: '$0' <cartella film> <elenco nomi film>'
    exit 1
fi
if [ ! -f $2 ];then
    echo 'Cartella non corretta ! Esempio: '$0' <cartella film> <elenco nomi film>'
    exit 1
fi
if [ -f output.txt ];then
    echo 'Esiste il file output.txt ! Lo elimino...'
    rm output.txt
fi
if [ $# -ne 2 ];then
    echo 'Parametri errati ! Esempio: '$0' <cartella film> <elenco nomi film>'
    exit 2
else

    elencoFilm=$(cat $2)
    count=0
    nomeFilm=''
    annoFilm=''
    estensioneFilm=''
    touch output.txt
    for i in $elencoFilm;do
        if [ $count -eq 0 ];then
            nomeFilm=$i;
            let count=$count+1
            continue
        fi
        if [ $count -eq 1 ];then
            annoFilm=$i
            let count=$count+1
            continue
        fi
        if [ $count -eq 2 ];then
            estensioneFilm=$i
            cartelle=$(ls $1)
            fileCartella="$nomeFilm.$estensioneFilm"
            for j in $cartelle;do
                if [ -f $1/$j/$fileCartella ];then
                    if [ "$annoFilm" == "$j" ];then
                        echo $fileCartella' '$annoFilm >> output.txt
                    else
                        echo "Errore: $nomeFilm $j invece di $annoFilm" >> output.txt
                    fi
                fi
            count=0
            done
        fi
    done
fi
