#Scrivere un programma shell (verifica_duplicati.sh) che riceva come parametri due file di testo (il primo conterrà una serie di coppie cartellaA cartellaB, una per #riga del file, mentre il secondo dovrà essere creato dal programma. Esempio d’uso sarà : verifica_duplicati.sh file_cartelle.txt file_output.txt.
#Per ogni coppia di cartelle il programma dovrà verificare che per ogni file contenuto nella cartellaA, non sia duplicato (cioè contenuto nella cartellaB). Se il file #risulta duplicato, il programma dovrà scrivere nel file file_output.txt il nome del file duplicato seguito dalla cartellaB in cui il file si trova.
#Gestire anche il controllo degli errori (parametri insufficienti, file di output già esistente, cartella inesistente, ecc..).

if [ $# -ne 2 ]; then
    echo "Devi inserire almeno due valori. Esempio stringa: verifica_duplicati.sh file_cartelle.txt file_output.txt"
fi
if [ ! -f $1 ]; then 
    echo "Devi inserire un file! Esempio stringa: verifica_duplicati.sh file_cartelle.txt file_output.txt"
fi
if [ -f $2 ]; then
    echo "Il file di output non deve esistere !!! Lo elimino."
    echo -n > $2
else


cartelle=$(cat $1)
touch $2
count=0
for i in $cartelle;do
    if [ $count -eq 0 ];then
        file1=$(ls $i)
        let count=1
    else
        file2=$(ls $i)
        echo "sono qui"
        for j in $file1; do
            for k in $file2; do
                if [ $j = $k ]; then 
                    echo "Trovato duplicato !"
                    echo $j >> $2
                fi
            done
            #if [ -f $file2/$j ]; then
             #   echo "Trovato duplicato !"
              #  echo $j >> $2
           # fi
        done
        let count=0
    fi
done


fi
