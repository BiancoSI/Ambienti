/*Scrivere un programma in C per la gestione di matrici di float, che contenga i seguenti metodi:
Una funzione create, che riceve due interi (dimensione di righe e colonne), crea una matrice delle dimensioni indicate, e restituisce il suo puntatore.
Un metodo read per la lettura di una matrice da tastiera.
Un metodo print per la stampa della matrice su output.
Un metodo punto_di_sella che restituisce (in maniera opportuna usando i puntatori) il valore, la riga e la colonna del primo punto
di sella presente nella matrice.
Si definisce punto di sella un elemento m[i,j] tale che esso risulti essere contemporaneamente il massimo fra tutti gli elementi
della riga i-esima e il minimo fra tutti gli elementi della colonna j-esima oppure risulti essere contemporaneamente
il minimo fra tutti gli elementi della riga i-esima e il massimo fra tutti gli elementi della colonna j-esima.  Il metodo ritorna false se non esistono punti di sella. Si consiglia di trovare tutti i massimi di una colonna e metterli in un vettore e fare lo stesso per i minimi delle righe. 
Il metodo main che dichiara e alloca la matrice  e invoca opportunamente i metodi precedenti.
*/

#include <stdio.h>
#include <stdlib.h>

typedef enum{false,true} bool;

float** create(int,int);
void erase(float**,int,int);
void print(float**,int,int);
void read(float**,int,int);
bool maxRiga(float**,int,int,int,float);
bool maxColonna(float**,int,int,int,float);
bool minRiga(float**,int,int,int,float);
bool minColonna(float**,int,int,int,float);
float puntoSella(float**,int,int,int*,int*);

int main(){
	float **mat;
	float pSella;
	int r,c,i;
	int riga;
	int colonna;
	printf("Inserire il numero di righe della matrice:\n");
	scanf("%d",&r);
	printf("Inserire il numero di colonne della matrice:\n");
	scanf("%d",&c);
	mat=create(r,c);
	erase(mat,r,c);
	printf("Inserire gli elementi della matrice:\n");
	read(mat,r,c);
	printf("Matrice letta:\n");
	print(mat,r,c);
	printf("\n");
	printf("Situazione dei punti di sella della matrice:\n");
	pSella=puntoSella(mat,r,c,&riga,&colonna);
	if(pSella!=-1){
		printf("L'ultimo punto di sella trovato è %f che si trova nella riga %d e nella colonna %d\n",pSella,riga,colonna);
	}
	else{
		printf("La matrice specificata NON contiene punti di sella\n");
	}
	printf ("Libero la memoria... \n");
	for (i=0;i<r;i++){
		free(mat[i]);
	}
	free(mat);
	return 0;
}

float** create(int r,int c){
	float **m;
	int i;
	m=(float**)malloc(r*sizeof(float*));
	if (m==NULL){
        	printf("MEMORIA NON DISPONIBILE! \n");
        	exit (-1);
	}
	else{
        	for (i=0;i<r;i++){
            		m[i]=(float*) malloc (c*sizeof(float));
            		if (m[i]==NULL){
                		printf("MEMORIA NON DISPONIBILE! \n");
                		free(m);
                		exit(-1);
            		}
        	}
	}
	return m;
}

void erase(float**m,int r,int c){
	int i,j;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			m[i][j]=0;
		}
	}
}

void read(float**m,int r,int c){
	int i,j;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			printf("m[%d,%d]> ",i,j);
			scanf("%f",&m[i][j]);
		}
	}
}

void print(float**m,int r,int c){
	int i,j;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			printf("%f\t",m[i][j]);
		}
	printf("\n");
	}
}
bool minRiga(float** m, int r,int c, int i, float f){
	int j;
	float min=m[i][0];
	for(j=0;j<c;j++){
		if(m[i][j]<min){
			min=m[i][j];
		}
	}
	if(min==f){
		return true;
	}
	else{
		return false;
	}
}

bool minColonna(float** m, int r,int c, int j, float f){
	int i;
	float min=m[0][j];
	for(i=0;i<r;i++){
		if(m[i][j]<min){
			min=m[i][j];
		}
	}
	if(min==f){
		return true;
	}
	else{
		return false;
	}
}

bool maxRiga(float** m, int r,int c, int i, float f){
	int j;
	float max=m[i][0];
	for(j=0;j<c;j++){
		if(m[i][j]>max){
			max=m[i][j];
		}
	}
	if(max==f){
		return true;
	}
	else{
		return false;
	}
}

bool maxColonna(float** m, int r,int c, int j, float f){
	int i;
	float max=m[0][j];
	for(i=0;i<r;i++){
		if(m[i][j]>max){
			max=m[i][j];
		}
	}
	if(max==f){
		return true;
	}
	else{
		return false;
	}
}

float puntoSella(float** m,int r,int c, int* riga,int* colonna){
	float pSella=-1;
	bool trovato=false;
	int i,j;
	for(i=0;i<r && !trovato;i++){
		for(j=0;j<c && !trovato ;j++){
			if((minRiga(m,r,c,i,m[i][j]) && maxColonna(m,r,c,j,m[i][j])) || (maxRiga(m,r,c,i,m[i][j]) && minColonna(m,r,c,j,m[i][j]))){
				printf("L'elemento della riga %d e della colonna %d è un punto di sella\n",i,j);
				*riga=i;
				*colonna=j;
				pSella=m[i][j];
			}
		}
	}
	return pSella;
}
