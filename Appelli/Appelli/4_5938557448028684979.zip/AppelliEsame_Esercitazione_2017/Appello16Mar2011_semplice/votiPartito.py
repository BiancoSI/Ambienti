#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys

#Scrivere un programma python che analizzi una serie di numeri che rappresentano i voti di un certo partito 
# per ogni giorno dell’anno (360 per semplicità).
#Il programma deve : 
#1) leggere dal file voti.txt tutti i voti e caricarli su una struttura dati adeguata
#2) Trovare il numero di voti massimo, minimo e la moda (cioè il numero di voti più presente nei dati).
#3) Supponendo che i mesi sono tutti di 30 giorni, rifare le stesse statistiche per i mesi e le settimane 
#Suggerimento: Per calcolare la moda, conviene utilizzare un dizionario.

def leggiVoti():
    if len (sys.argv) != 2:      #nome del programma + file da cui leggere il vettore
        print("Uso: %s <nome_file>" % sys.argv[0])
        sys.exit (-1)
    filename=sys.argv[1]
    v=[]
    
    try: 
        with open(filename,'r') as fp:
            for i in fp:
                linea=i.strip().split()
                v.append(int(linea[1]))
    except IOError:
        print("Il file %s non è stato trovato" % filename)
        sys.exit (-1)
    
    return v

def calcolaModa(listaVoti):
    d={}
    for voti in listaVoti:
        if voti not in d:
            d[voti]=1
        else:
            d[voti]+=1
    listaFrequenze=d.values()
    valMax=trovaValoreMassimo(d)
    if valMax[1]>1:
        print("Il voto più presente tra i dati è %d con %d occorrenze" % (valMax[0], valMax[1]))
    else:
        print("Nel periodo considerato non sono presenti voti ripetuti")
    # se i voti nel periodo considerato occorrono una volta non ha senso calcolare la moda

def trovaValoreMassimo(d):
    l=d.items() # -> [(voti,frequenza), ...]
    valMax=l[0] # -> (voti,frequenza)
    for voti, frequenza in l:
        if frequenza > valMax[1]:
            valMax = (voti,frequenza)
    return valMax

def trovaVotoMassimo(v):
    print("Il voto massimo ricevuto è %d" % max(v))
    
def trovaVotoMinimo(v):
    print("Il voto minimo ricevuto è %d" % min(v))

def stampaVoti(v):
    print(v)

def calcolaStatistiche(v):
    stampaVoti(v)
    calcolaModa(v)
    trovaVotoMassimo(v)
    trovaVotoMinimo(v)

def calcolaStatisticheMensili(v):
    i = 0
    mese = 1
    print("RIEPILOGO DELLE STATISTICHE MENSILI:")
    for k in range(12):
        m = v[i:i+30]
        print("MESE %d" %mese)
        calcolaStatistiche(m)
        mese += 1
        i += 30
        
def calcolaStatisticheSettimanali(v):
    i = 0
    sett = 1
    print("RIEPILOGO DELLE STATISTICHE SETTIMANALI:")
    for k in range(52):
        s = v[i:i+7]
        print("SETTIMANA %d" %sett)
        calcolaStatistiche(s)
        sett += 1
        i += 7
        
def calcolaStatisticheAnnuali(v):
    print("RIEPILOGO DELLE STATISTICHE ANNUALI:")
    calcolaStatistiche(v)

if __name__ == "__main__":
    v=leggiVoti()
    calcolaStatisticheAnnuali(v)
    calcolaStatisticheMensili(v)
    calcolaStatisticheSettimanali(v)
