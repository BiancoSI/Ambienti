import sys
from operator import *

def readFile(fName):
	lParole=[]
	if fName=='' or fName==None:
		raise RuntimeError
	try:
		sf=open(fName,'r')
	except IOError:
		print "Errore nell'apertura del file"
		sys.exit(1)
	tmp=sf.readlines()
	for i in tmp:
		t = i.split()
		#Non rimuove punti alla fine della parola, viene lasciato come esercizio
		lParole.extend(t)
	print "File letto con successo!"
	#trasformo le parole in minuscole
	lParole=[x.lower() for x in lParole]
	#rimuovi punto dalle parole
	lParole=[x.replace('.', '')for x in lParole]
	return lParole
		
def LongerWords(lParole):
	if len(lParole)==0:
		raise RuntimeError
	diz={}
	for parola in lParole:
		if len(parola)>5:
			if parola not in diz:
				diz[parola]=1
			else:
				diz[parola]=diz[parola]+1
	tmp=[]
	for i,j in diz.items():
		if j>10:
			tmp.append(i)
	tmp.sort(key=len)
	return tmp

def SortedWords(lParole):
	if len(lParole)==0:
		raise RuntimeError
	# se ordiniamo prima le parole, verrano poi inserite nella lista associata al dizionario in ordine corretto
	# altrimenti poi dobbiamo copiare i valori  del  dizionario in una lista e ordinarlo (vedi SortedWordsBis) 	
	tmp=sorted(lParole)
	diz={}
	for parola in tmp:
		lenPar=len(parola)
		if lenPar>8:
			if lenPar not in diz:
				l=[parola]
				diz[lenPar]=l
			else:
				if parola not in diz[lenPar]:            #evita che siano inserite parole duplicate
					diz[lenPar].append(parola)
	#ordino anche in ordine inverso di lunghezza (non richiesto dalla traccia, ma piu' elegante per stampare poi)
	lista=diz.values()
	lista.sort(reverse=True)				
	return lista


def SortedWordsBis(lParole):
	if len(lParole)==0:
		raise RuntimeError
	diz={}
	for parola in lParole:
		lenPar=len(parola)
		if lenPar>8:
			if lenPar not in diz:
				l=[parola]
				diz[lenPar]=l
			else:
				if parola not in diz[lenPar]:            #evita che siano inserite parole duplicate
					diz[lenPar].append(parola)
	lista=diz.values()
	#ordino, per ogni lunghezza, la lista di parole associate in ordine alfabetico
	for i in range(len(lista)):
		lista[i].sort()
		
	#ordino anche in ordine inverso di lunghezza (non richiesto dalla traccia, ma piu' elegante per stampare poi)
	lista.sort(reverse=True)				
	return lista


if __name__=="__main__":
	nFile=raw_input("Inserisci il nome del file da analizzare> ")
	listaParole=readFile(nFile)
	try:
		lWords=LongerWords(listaParole)
		sWords= SortedWords(listaParole)
		sWordsBis= SortedWordsBis(listaParole)
		
		print "\nLe parole piu' lunghe di 5 caratteri ordinate per lunghezza sono (scrivo 10 parole per riga):"
		conta=0
		for i in  lWords:
			print "%s\t" %i,
			conta=conta+1
			if conta%10==0:
				print
		print "\n"
		print "\nLe parole, in ordine lessicografico, piu' lunghe di 8 caratteri raggruppate per lughezza sono (metodo 1):"
		
		for i in sWords:
			print "Lunghezza %d" %len(i[0])
			for j in  i:
				print "%s\t" %j,
			print "\n"
		print "\n"
		print "\nLe parole, in ordine lessicografico, piu' lunghe di 8 caratteri raggruppate per lughezza sono (metodo 2):"
		
		for i in sWordsBis:
			print "Lunghezza %d" %len(i[0])
			for j in  i:
				print "%s\t" %j,
			print "\n"
	
	
	except RuntimeError:
		print "Errore nel nome del file"
		sys.exit(1)

