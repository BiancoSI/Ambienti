#!/usr/bin/env python
# -*- coding: utf-8 -*-


#~ Scrivere un programma python che analizzi il contenuto testuale di un file Esame.txt.
#~ Supponendo che esista già (chi vuole la può realizzare facilmente) la funzione isNumber(s) che restituisce True se la stringa s è un numero, False altrimenti.
#~ Il programma deve :
#~ 1) leggere tutte le parole contenute nel file e caricarle su una struttura dati adeguata, separando numeri e parole (per semplicità escludiamo i segni di punteggiatura).
#~ 2) Trovare tutte le parole ripetute più di 4 volte e stamparle.
#~ 3) Fare la media, il massimo e il minimo di tutti i numeri trovati che siano compresi fra 0 e 30.
#~ 4) Stampare il numero di occorrenze dei numeri ripetuti più di 1 volta, dal maggiore al minore, sempre che verifichino la proprietà di cui sopra. (Esempio: 30 5 volte, 29 6 volte, 28 4 volte).

import sys

def isNumber(s):
    for c in s:
        if c not in '0123456789':
            return False
    return True

def leggiFile(nomeFile):
    data = {'parole':[], 'numeri':[]}
    try:
        with open(nomeFile) as fp:
            content = fp.read()
        for word in content.strip().split():
            if isNumber(word):
                data['numeri'].append(int(word))
            else:
                data['parole'].append(word)
    except Exception as e:
        print('ERRORE: %s' % e)
        sys.exit(1)
    
    return data

def punto2(data):
    diz = {}
    for word in data['parole']:
        if word in diz:
            diz[word] += 1
        else:
            diz[word] = 1
    
    print('Parole ripetute più di 4 volte')
    print('Parola ripetizioni')
    for word in diz:
        if diz[word] > 4:
            print('%s\t%s' % (word, diz[word]))

def estraiNumeri(data):
    l = [int(x) for x in data['numeri']]
    return [x for x in l if 0<=x<=30]

def punto3(data):
    l = estraiNumeri(data)
    minimo = min(l)
    massimo = max(l)
    media = sum(l) / float(len(l))
    
    print
    print('il minimo è %s' % minimo)
    print('il massimo è %s' % massimo)
    print('la media è %.2f' % media)
    
def punto4(data):
    l = estraiNumeri(data)
    diz = {}
    for n in l:
        if n in diz:
            diz[n] += 1
        else:
            diz[n] = 1
    
    numeriOrdinati = sorted(diz.items(), reverse=True)
    
    print('Numeri ripetute più di 1 volta')
    print('Numero ripetizioni')
    for n,r in numeriOrdinati:
        if r > 1:
            print('%s\t%s' % (n, r))



if __name__ == "__main__":
 
    if len(sys.argv) == 2:
        fname = sys.argv[1]
        data = leggiFile(fname)
        print "parole:"
        for i in data['parole']:
        	print "%s\t" % i,
        print
        print "numeri:"
        for i in data['numeri']:
        	print "%d\t" %i,
        print
        
        punto2(data)
        punto3(data)
        punto4(data)
    else:
        print('Usage: %s nomefile' % sys.argv[0])
        sys.exit(1)

