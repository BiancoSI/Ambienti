#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#define N 10

//figlio1  ->  Fmul2
//figlio2 -> Fmul3
int main()
{
	
	int pFmul1[2];//padre-figlio1
	int pFmul2[2];//padre-figlio2
	int Fmul1n[2];//figlio1-nipote
	int Fmul2p[2];//figlio2-padre
	
	int status;
	int pd1,pd2,pd3;
	int vettore[N]={1,2,3,4,5,6,7,8,9,10};//per comodità uso un vettore da 10 e non 100 elementi
	
	int f=open("vettori.bin",O_WRONLY|O_CREAT,0777);
	if(f==-1){
		printf("Errore nella creazione del file\n");
		exit(1);
	}
	int indice,val;
	for(indice=0;indice<N;indice++){
		write(f,&vettore[indice],sizeof(int));
	}
	close(f);
	if(pipe(pFmul1)==-1){
		fprintf(stderr,"Errore nella creazione dei canali:1");
		exit(0);
	}
	
	if(pipe(pFmul2)==-1){
		fprintf(stderr,"Errore nella creazione dei canali:2");
		exit(0);
	}
	
	if(pipe(Fmul1n)==-1){
		fprintf(stderr,"Errore nella creazione dei canali:3");
		exit(0);
	}
	
	if(pipe(Fmul2p)==-1){
		fprintf(stderr,"Errore nella creazione dei canali:4");
		exit(0);
	}
	
	pd1=fork();
	
	switch(pd1){
	
	case -1:
		fprintf(stderr,"Errore nella creazione dei processi");
		exit(0);
		
	case 0://figlio1  Fmul2
		pd3=fork();
		if(pd3>0){//figlio1
			close(pFmul1[1]);
			close(Fmul1n[0]);
			int val;
			read(pFmul1[0],&val,sizeof(int));	
			while(val!=0){
				if(val%2==0)
					write(Fmul1n[1],&val,sizeof(int));
				read(pFmul1[0],&val,sizeof(int));
			}
			int zero=0;
			write(Fmul1n[1],&zero,sizeof(int));
			wait(&status);
			exit(0);
		}
		else{
			if(pd3==0){//nipote
				close(Fmul1n[1]);
				int val,cont=0;
				float somma;
				read(Fmul1n[0],&val,sizeof(int));	
				while(val!=0){
					somma+=val;
					cont++;
					read(Fmul1n[0],&val,sizeof(int));
				}
				char  buffer[100];
				float media;
				media=somma/(float) cont;
				sprintf(buffer,"%2.f",media);
				int fd=open("Media.txt",O_WRONLY|O_CREAT,0777);
				write(fd,buffer,strlen(buffer));
				close(fd);
				exit(0);
			}
			else{
				fprintf(stderr,"Errore nella creazione dei processi");
				exit(0);
			}
		}
	default:
		
		pd2=fork();
		if(pd2>0){//padre
		    int cont;
		    char parola[5];
		    int vett[N];
			int i;
			int fd;
			int zero=0;//valore per terminare la lettura dalla pipe
			close(pFmul1[0]);
			close(pFmul2[0]);
			close(Fmul2p[1]);
			
			fd=open("vettori.bin",O_RDONLY);
			
			for(i=0;i<N;i++){
				read(fd,&vett[i],sizeof(int));
			
			}	 
            cont=0;
			for(i=0;i<N;i++){
				if(vett[i]%2==0)
					write(pFmul1[1],&vett[i],sizeof(int));
				if(vett[i]%3==0){
					write(pFmul2[1],&vett[i],sizeof(int));
					cont++;	
				}
			}
			
			write(pFmul1[1],&zero,sizeof(int));
			write(pFmul2[1],&zero,sizeof(int));
			
			read(Fmul2p[0],parola,5*sizeof(char));	
			while(cont>0){				
				printf("%s\n",parola);
				read(Fmul2p[0],parola,5*sizeof(char));
				cont--;
			}
			close(fd);
			wait(&status);
			wait(&status);
		}  // fine padre
		else{
			if(pd2==0){//figlio2 Fmul3
			    int val;
				char sup[]="sup5";
				char inf[]="inf5";
				close(pFmul2[1]);
				close(Fmul2p[0]);
				
				read(pFmul2[0],&val,sizeof(int));	
				while(val!=0){
					if(val>=5){
						write(Fmul2p[1],sup,5*sizeof(char));
					}
					else{
						write(Fmul2p[1],inf,5*sizeof(char));
					}
					read(pFmul2[0],&val,sizeof(int));
				}
				exit(0);
			}
			else{   //pd==-1
				fprintf(stderr,"Errore nella creazione dei processi");
				exit(0);
			}
		}
	}
}
