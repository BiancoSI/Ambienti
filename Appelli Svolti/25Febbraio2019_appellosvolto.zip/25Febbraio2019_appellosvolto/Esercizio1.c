#include <stdio.h>
#include <stdlib.h>

int** create(int r, int c){
	if(r<=0 || c<=0){
		printf("Parametri errati\n");
		exit(1);
	}
	int i,j;
	int** mat=(int**)malloc(r*sizeof(int));
	if(mat==NULL){
		printf("Errore nell'allocazione della memoria\n");
		exit(1);
	}
	for(i=0;i<r;i++){
		mat[i]=(int*)malloc(c*sizeof(int));
		if(mat[i]==NULL){
			printf("Errore nell'allocazione della memoria\n");
			for(j=0;j<i;j++)
				free(mat[j]);
			free(mat);
			exit(1);
		}
	}
	return mat;
}
void read(int** mat, int r, int c){
	if(mat==NULL || r<=0 || c<=0){
		printf("Parametri errati\n");
		exit(1);
	}
	int i,j;
	for(i=0;i<r;i++)
		for(j=0;j<c;j++){
			printf("Inserisci mat[%d][%d]>",i,j);
			scanf("%d",&mat[i][j]);
		}
}
void print(int** mat, int r, int c){
        if(mat==NULL || r<=0 || c<=0){
                printf("Parametri errati\n");
                exit(1);
        }
	int i,j;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++)
			printf("%d\t",mat[i][j]);
		printf("\n");
	}
}

int minimoColonna(int** mat, int j,int r){
        int i,min;
        if(mat==NULL || r<=0 || j<0){
                printf("Parametri errati\n");
                exit(1);
        }
        min=mat[0][j];
        for(i=0;i<r;i++)
	         if(min>mat[i][j])
	              min=mat[i][j];
        return min;
}


int minoreColonna(int** mat, int i,int j, int r){
        int val, k;
        if(mat==NULL || r<=0 || i<0 || j<0){
                printf("Parametri errati\n");
                exit(1);
        }
        val=mat[i][j];
        for(k=0;k<r;k++)
	       if(val>mat[k][j]) 
	            return 0;
        return 1;
}
int sommaRiga(int** mat, int riga, int c){
        int j;
        int somma=0;
        if(mat==NULL || riga<0 || c<=0){
                printf("Parametri errati\n");
                exit(1);
        }
        
        for(j=0;j<c;j++)
                somma+=mat[riga][j];
        return somma;
}


void somma_minima_meno_efficiente(int** mat, int r, int c, int *valore, int *riga, int *colonna){
	if(mat==NULL || c<=0 || r<=0 || valore==NULL || riga==NULL || colonna==NULL){
		printf("Parametri errati\n");
                exit(1);
	}
	int i,j;
	int trovato=0;
	for(i=0;i<r;i++){
		for(j=0;j<c;j++)
			if(!trovato && mat[i][j]*c>sommaRiga(mat,i,c) && minoreColonna(mat,i,j,r)){
				*valore=mat[i][j];
				*riga=i;
				*colonna=j;
				trovato=1;
			}
	}
}

// versione efficiente
void somma_minima(int** mat, int r, int c, int *valore, int *riga, int *colonna){
	int i,j;
	int trovato=0;
	int *vSommariga;
	int *vMinCol;
	if(mat==NULL || c<=0 || r<=0 || valore==NULL || riga==NULL || colonna==NULL){
		printf("Parametri errati\n");
                exit(1);
	}
	
	vSommariga=(int *) malloc (sizeof(int)*r);
	vMinCol=(int *) malloc (sizeof(int)*c);
	for(i=0;i<r;i++)
	    vSommariga[i]=sommaRiga(mat,i,c);
	for(j=0;j<c;j++)
	    vMinCol[j]=minimoColonna(mat, j,r);
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++)
			if(!trovato && (mat[i][j]*c)>vSommariga[i] && mat[i][j]==vMinCol[j]){
				*valore=mat[i][j];
				*riga=i;
				*colonna=j;
				trovato=1;
			}
	}
}


int main(int argc, char* argv[]){
	int r,c,riga,colonna,valore;
	printf("Inserisci <numeroRighe numeroColonne>");
	scanf("%d %d",&r,&c);
	int** mat=create(r,c);
	read(mat,r,c);
	print(mat,r,c);
	somma_minima(mat,r,c,&valore,&riga,&colonna);
	printf("valore=%d, riga=%d, colonna=%d\n",valore,riga,colonna);
	return 0;
}
