if [ $# -ne 2 ];then
	echo "Uso $0 <cartellaCandidati><FileVinc>"
	exit 1
fi
if [ ! -d $1 ];then
	echo "Parametri errati"
fi
fileCartella=$(ls $1)
vincitore=''
punteggioMax=0
echo "GRADUATORIA" >> $2
for file in $fileCartella;do
	voti=$(cat $1/$file)
	totalePunteggio=0
	for voto in $voti;do
		let totalePunteggio=$totalePunteggio+$voto
	done
	if [ $totalePunteggio -gt $punteggioMax ];then
		punteggioMax=$totalePunteggio
		vincitore=$(echo $file | sed 's/\.txt$//')
	fi
	echo "$totalePunteggio $(echo $file | sed 's/\.txt$//') " >> $1/tmp
done
echo $(cat $1/"tmp" | sort -n) > $1/tmp
count=0
nome=''
voto=0
fileTmp=$(cat $1/tmp)
for stringa in $fileTmp; do
	case $count in
	0) let count=$count+1
	   voto=$stringa;;
	1)let count=$count+1
	   nome=$stringa
	   echo "$nome $voto punti" >> $2; 
	   count=0; 
	   voto=0;;
	esac
done
rm $1/tmp
echo "VINCITORE $vincitore $punteggioMax punti" >> $2

