import sys

def leggi():
	l=[]	
	if len(sys.argv)!=2:
		print "Errore sintassi: python %s <file_password>" % sys.argv[0]
		exit(-1)
	nomefile=sys.argv[1]
	if cmp(nomefile,"password.txt")!=0:
		print "nome file non corretto"
		exit(-1)
	linee=open(nomefile)
	for i in linee:
		l.append(i.strip().split())

	return l

def passw_non_sicure(lista):
	passwnsicure=0
	for i in lista:
		if len(i[1])>=8:
			contiene_numero=False
			contiene_carattere=False
			for j in i[1]:
				if '0'<=j<='9':
					contiene_numero=True
				if j=='_' or j=='.':
					contiene_carattere=True
			if not (contiene_numero and contiene_carattere):
				passwnsicure+=1
		else:
			passwnsicure+=1
	return passwnsicure


def stessapassword(lista):
	listapassw=[]
	listanomi=[]
	d={}
	for i in lista:
		k=i[1]
		if k not in d:
			d[k]=i[0]
		else:
			if k not in listapassw:
				listapassw.append(k)
	#ho la lista con password comuni almeno a due utenti
		
		
	for i in listapassw:
		sottolistanomi=[]
		for j in lista:
			if i==j[1]:
	 			sottolistanomi.append(j[0])
		if len(sottolistanomi) != 0:
			listanomi.append(sottolistanomi)
		#piu' completo: restituisco una lista di liste
		#ogni sottolista ha in se' gli utenti con una stessa password
		
	return listanomi


if __name__== "__main__":
	
	lista=leggi()
	print "Utente\tPassword " 
	for i in lista:
		print "%s\t%s" % (i[0], i[1])
	print "il numero di password non sicure e': " 
	print passw_non_sicure(lista)
	print "\nla lista degli utenti aventi la stessa password e': " 
	print  stessapassword(lista)
				
			
				
			
				
			
