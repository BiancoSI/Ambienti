if [ $# -ne 3 ];then
	echo "errore sintassi: $0 <cartella> <cartella> <file>"
	exit -1
fi
if [ ! -d $1 ];then
	echo "cartella $1 inesistente"
	exit -2
fi
if [ ! -d $2 ];then
	echo "cartella $2 inesistente"
	exit -3
fi
if [ ! -f $3 ];then
	echo "file $3 inesistente"
	exit -4
fi
conta=0
uguale=0
tot=0

est=$(cat $3)
fileC1=$(ls $1)
for i in $fileC1;do
	let tot=$tot+1
	uguale=0
	for j in $est;do
		ext=$(echo $i | sed 's/^.*\.//')
		#ho preso dal nome del file $i contenuto nella cartellaA, la sua estensione supponendo che ci sia solo un punto prima di essa
		
		if [ $ext = $j ];then
			uguale=1
		fi		
	done
	if [ $uguale -eq 0 ];then
		if [ -f $2/$i ];then
			echo "il file esiste già, verrà quindi rimosso da $2 e copiato quello proveniente da $1"
			rm $2/$i
		fi			
		echo "copio $i in $2"
		cp $1/$i $2
		let conta=$conta+1	
	fi			
done
let noncop=$tot-$conta
echo "il numero di file copiati è: $conta"
echo "il numero di file non copiati è: $noncop"
