/* Un metodo trova_righe_colonne che ha come parametri una matrice e un vettore e, 
dopo aver verificato che la matrice sia quadrata, restituisce:
1) il numero di righe perfettamente uguali al vettore considerato (esempio la colonna [10 20 30 40 50 60] e
 il vettore [30 50 60 20 10 40] non rispettano la condizione perché l’ordine non è rispettato).
2) e il numero di colonne che differiscono al più di 2 elementi dal vettore considerato,
 anche non nell’ordine, esempio la colonna [10 20 30 40 50 60] e il vettore [30 50 60 20 9 8], differiscono solo di 2 elementi (9 e 8), 
 quindi la condsizione è verificata.
*/


#include <stdio.h>
#include <stdlib.h>
typedef enum {false,true} boolean;
float** create(int, int);
void read(float **,int, int);
void print(float **,int, int);
void trova_righe_colonne(float **mat, int n, int m, float *vet, int dim, int *righe, int* col);



int main()
{
	int r,c, dim, i, j;
	int righe,col;
	float **mat;
	float  vet[]={10.0,20.0,30.0};
	
	printf("Inserisci righe matrice>");
	scanf ("%d",&r);
	printf("Inserisci colonne matrice>");
	scanf ("%d",&c);
	mat=create(r,c);  // alloca la matrice
	read(mat,r,c);
	print(mat,r,c);
	
	trova_righe_colonne(mat, r,c, vet, dim, &righe, &col);
	
	printf("Le righe che verificano sono %d, le colonne sono %d\n",righe, col);
	
	
	return 0;

}


float** create(int n, int m){
float **mat;
int i,k;
mat=(float **) malloc (sizeof (float *) * n);
if (mat==NULL){
	printf("mem non disponibile\n");
	exit (1);
}

for (i=0;i<n;i++){
	mat[i]=(float *)malloc (sizeof (float)*m);
	if (mat[i]==NULL){
		printf("mem non disponibile\n");
		for (k=0;k<i;k++)
			free (mat[k]);
 		free(mat);
		exit (1);
	}
}
	
return mat;
}

void read(float ** mat,int n, int m){
int i,j;
for (i=0;i<n;i++)
	for (j=0;j<m;j++){
		printf ("Inserisci mat[%d][%d]>",(i+1),(j+1));
		scanf ("%f",&mat[i][j]);
	}		
}	

void print(float **mat, int r, int c)
{
int i,j;
for (i=0;i<r;i++){
	for (j=0;j<c;j++)
		printf("%.2f\t",mat[i][j]);
	printf("\n");
}
}


void trova_righe_colonne(float **mat, int r, int c, float *vett, int len, int *righe, int *col) {
    
    if (c != len) {
        printf("Error: dimensione vettore diversa da dimensione colonne matrice!\n");
        exit(1);
    }

    int i,j,k,count;
    boolean uguali, trovato;
    
    //calcoliamo le righe che soddisfano la condizione
    *righe = 0;
    for (i=0; i<r; i++) {
        uguali = true;
        for (j=0; j<c && uguali; j++){
            if (mat[i][j] != vett[j]) {
                uguali = false;
            }
        }
        if (uguali) {
            *righe += 1;
        }
    }

    //calcoliamo le colonne che soddisfano la condizione
    *col = 0;
    for (j=0; j<c; j++) {
        count = len; //suppongo inizialmente che tutti i valori siano diversi
        for (k=0; k<r; k++) {
            trovato = false;
            for (i=0; i<r && !trovato; i++) 
                if (vett[k] == mat[i][j])
                    trovato = true;
            if (trovato)
                count -= 1; //abbiamo trovato l'elemento del vet, quindi un valore diverso in meno
        } //end for k del vettore
        if (count <= 2) {
            *col += 1;
        } // end for j sulle colonne
    }
}



	
		
	


