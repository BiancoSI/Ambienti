/* Scrivere un programma in C per la gestione di matrici di interi, che contenga i seguenti metodi:
Una funzione create, che riceve due interi (dimensione di righe e colonne), crea una matrice delle dimensioni indicate, e restituisce il suo puntatore.
Un metodo read per la lettura di una matrice da tastiera.
Un metodo print per la stampa della matrice su output.
Un metodo resituisci_min_vett che restituisce (in maniera opportuna usando i puntatori) il minimo della matrice e un vettore v costruito come indicato di seguito.
Il vettore V è formato da tutti gli elementi della matrice che si trovino nelle righe pari e che siano maggiori di 2 volte il minimo.
Il metodo main che dichiara e alloca la matrice  e invoca opportunamente i metodi precedenti. */
#include <stdio.h>
#include <stdlib.h>
typedef enum{false,true} boolean;
int  ** create(int, int);
void read(int ** m,int , int);
void print(int ** m,int , int);
int *  restituisci_min_vett(int ** ,int, int, int*, int*);



int main(){
	int  ottimo;
	int r,c,i;
	int ** mat;
	int minimo;
	int dimV;
	printf("dammi la dimensione delle righe\n ");
	scanf("%d",&r);
	printf("dammi la dimensione delle colonne\n ");
	scanf("%d",&c);
	mat=create(r,c);
	read(mat,r,c);
	print(mat,r,c);
	int * vettore=(int *)restituisci_min_vett(mat,r,c,&minimo,&dimV);
	printf("\nIl minimo della matrice data è: %d\n", minimo);
	
	printf ("Il vettore cercato è: \n");
	
	for (i=0;i<dimV;i++)
		printf ("%d\t", vettore[i]);
	printf("\n");
	printf("libero spazio di memoria...\n");
	for (i=0;i<r;i++)
		free(mat[i]);
	free(mat);
	free(vettore);
	return 0;
}

int** create(int r, int c){
	int i;
	int ** m =(int**)malloc(r*sizeof(int*));
	if(m==NULL){
		printf ("spazio non disponibile\n");
		exit(-1);
	}
	for(i=0;i<r;i++){
		m[i]=(int*)malloc(c*sizeof(int));
		if (m[i]==NULL){
			printf ("spazio non disponibile\n");
			free(m);
			exit (-1);
		}
	}
	return m;
} 

void read(int**m, int r, int c){
	int i,j;
	printf("lettura elementi matrice\n");
	for (i=0;i<r;i++)
		for(j=0;j<c;j++){
			printf("dammi l'elemento m[%d][%d]  ",i,j);
			scanf("%d",&m[i][j]);
		}
}

void print(int ** m, int r, int c){
	int i,j;
	printf("la matrice data è:");
	for (i=0;i<r;i++){
		printf("\n");
		for(j=0;j<c;j++)
			printf("%d\t",m[i][j]);
	}
}

int* restituisci_min_vett(int** m,int r, int c, int* minimo, int* dimV){
	int i,j; 
	int dim;
	//calcolo il minimo della matrice
	int min=m[0][0];
	for (i=0;i<r;i++)
		for(j=0;j<c;j++){
			if(m[i][j]<min)
				min=m[i][j];
			
	}
	
	
	//calcolo la dimensione del vettore
	for (i=0;i<r;i=i+2)
		for(j=0;j<c;j++){
			if(m[i][j]>2*min){
				dim+=1;
			}
	}
	//alloco il vettore della dimensione esatta
	int * vettore=(int*)malloc(dim*sizeof (int));
	if(vettore==NULL){
		printf ("spazio non disponibile\n");
		exit (-1);	
	}

	//popolo il vettore
	int k=0;
	for (i=0;i<r;i=i+2)
		for(j=0;j<c;j++){
			if(m[i][j]>2*min){
				vettore[k]=m[i][j];			
				k+=1;
					
			}
	}
	//ritorno i valori
	*minimo=min;
	*dimV=dim;
	return vettore;
}



