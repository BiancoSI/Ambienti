#! /usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Scrivere un programma python che faccià una serie di statistiche.
# Il programma deve : 
# 1) leggere dal file numeri.txt tutte le triple nome, età, stipendio e caricarle su una struttura dati adeguata
# 2) Restituire il numero e il nome delle persone che hanno uno stipendio maggiore di 100 mila euro.
# 3) Restituire una lista di nomi di persone  che abbiano la stessa età, ordinate per stipendio.  
# Sarà apprezzato l’inserimento dei metodi all’interno di una classe Statistiche. 
# Suggerimento:  Se l’esercizio risulta troppo difficile provare a svolgerlo senza ordinare per stipendio al punto 3.

import sys
from operator import *

def leggi():
	
	if len(sys.argv)!=2:
		print "Errore sintassi: python %s <filenumeri>" % sys.argv[0]
		exit(-1)
	nomefile=sys.argv[1]
	try:
		f=open(nomefile)
	except IOError:
		print "il file delle password non è stato trovato!!"
		sys.exit(-1)
	linee=f.readlines()
	f.close()
	l=[]
	for i in linee:
		listi=i.strip().split()
		listi[2]=int(listi[2])
		l.append(listi)

	return l

def stipendio_magg_100mila(lista):
	ris=[0,[]]
	for i in lista:
		if i[2]>100000:
			ris[0]+=1
			ris[1].append(i[0])
			
	return ris


def persone_stessa_eta(lista):
	#ordino la lista lis in modo decrescente rispetto allo stipendio in modo tale che quando poi inserirò nel dizionario i nomi delle persone in corrispondenza della stessa password tali nomi risulteranno ordinati per stipendio. PS: se si vuole l'ordinamento crescente (dallo stipendio più piccolo al più grande) basta togliere il parametro reverse=True nel metodo sort()
	#lista=sorted(lis,key=itemgetter(2),reverse=True)
	lista.sort(key=itemgetter(2))
	
	
	d={}
	for i in lista:
		eta=i[1]
		if eta not in d:
			el=[i[0], i[2]]
			d[eta]=[]
			d[eta].append(el)
		else:
			el=[i[0], i[2]]
			d[eta].append(el)
	
	print "Le persone raggruppate per età sono: \n"
	print d

	diz={}
	for i in d:
		if len(d[i])>1:
			diz[i]=d[i]
	return diz



if __name__== "__main__":
	
	lista=leggi()
	
	print "Utente\t\tEtà\tStipendio " 
	for i in lista:
		print "%s\t\t%s\t%s" % (i[0], i[1],i[2])
	
	l=stipendio_magg_100mila(lista)
	numero=l[0]
	print "Il numero di persone con lo stipendio maggiore di 100 mila euro é: %d\n " %numero
	print "Le persone con lo stipendio maggiore di 100 mila euro sono: \n"
	print l[1]
	print
	diz=persone_stessa_eta(lista)
	for i in diz:
		print "Le persone aventi come età %s sono:\n " %i
		print diz[i]
		print "\n"

	
				
			
				
			
				
			
