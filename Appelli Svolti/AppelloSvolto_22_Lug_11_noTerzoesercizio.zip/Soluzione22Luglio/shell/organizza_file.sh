# Scrivere un programma shell (organizza_file.sh) che riceva come parametri un file di testo e due cartelle. Esempio d’uso sarà : organizza_file.sh nomefile.txt  cartellaA cartellaB. Il file conterrà per ogni riga il nome di un file (che è presente nella cartella corrente) e la lettera A oppure la lettera B.
# Per ogni file letto da nomefile.txt, se la lettera corrispondente è la lettera A, bisognerà copiare il file nella prima cartella (cartellaA nell’esempio), altrimenti nella seconda cartella (attenzione, i nomi delle cartelle sono passati come parametri, quindi non devono per forza essere cartellaA e cartellaB!!!!!). Se il file è già presente nella rispettiva cartella, bisognerà evitare di copiarlo e scrivere su output un messaggio.
# Alla fine si dovrà stampare in output il numero dei file copiati nella cartella cartellaA e nella cartella cartellaB e di quelli che non sono stati copiati.
# Gestire anche il controllo degli errori (parametri insufficienti, cartella inesistente, ecc..).
if [ $# -ne 3 ];then
	echo "errore sintassi: $0 nomefile.txt <cartellA> <cartellaB>"
	exit -1
fi
if [ ! -f $1 ];then
	echo "file $1 inesistente"
	exit -4
fi
if [ ! -d $2 ];then
	echo "cartella $3 inesistente"
	exit -2
fi
if [ ! -d $3 ];then
	echo "cartella $3 inesistente"
	exit -3
fi


contaA=0
contaB=0
k=0
tot=0
nomefile=""

files=$(cat $1)
for i in $files;do
	
	let k=$k%2
	if [ $k -eq 0 ];then
		let tot=$tot+1
		nomefile=$i
	else	
		if [ $i = 'A' ];then
			if [ -f ./$nomefile ]; then
				if [ -f $2/$nomefile ]; then
					echo "il file $nomefile è già presente in $2"	
				else
					echo "copia di $nomefile in $2"
					cp ./$nomefile $2
					let contaA=$contaA+1
				fi	
			else
				echo "il file $nomefile non esiste nella directory corrente"
			fi
		else
			if [ -f ./$nomefile ]; then
				if [ -f $3/$nomefile ]; then
					echo "il file $nomefile è già presente in $3"	
				else
					echo "copia di $nomefile in $3"
					cp ./$nomefile $3
					let contaB=$contaB+1
				fi	
			else
				echo "il file $nomefile non esiste nella directory corrente"
				
			fi
		fi
	fi
	let k=$k+1		
done
let noncop=$tot-$contaA-$contaB
echo "il numero di file copiati in $2 è: $contaA"
echo "il numero di file copiati in $3 è: $contaB"
echo "il numero di file non copiati è: $noncop"
