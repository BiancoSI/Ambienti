#include <stdio.h>
#include <stdlib.h>

int main(){
	int x=10;
	int *px;
	
	px=&x;
	
	printf("left value (indirizzo) di x = %p\n", &x);
	printf("px (puntatore) = %p\n", px);
	printf("right value (valore) di x = %d\n", x);
	printf("valore puntato da px (*px) = %d\n", *px);
	
	x=20;
	printf("left value (indirizzo) di x = %p\n", &x);
	printf("px (puntatore) = %p\n", px);
	printf("right value (valore) di x = %d\n", x);
	printf("valore puntato da px (*px) = %d\n", *px);	
	
	*px=30;
	printf("left value (indirizzo) di x = %p\n", &x);
	printf("px (puntatore) = %p\n", px);
	printf("right value (valore) di x = %d\n", x);
	printf("valore puntato da px (*px) = %d\n", *px);	
	return 0;
}
