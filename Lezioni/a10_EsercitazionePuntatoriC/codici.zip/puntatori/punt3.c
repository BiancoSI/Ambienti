#include <stdio.h>
#include <stdlib.h>

int main(){
	int x=10;
	int y=20;
	int z=30;
	int *px;
	
	px=&x;
	
	printf("indirizzo (&x) di x = %p\n", &x);
	printf("indirizzo (&y) di y = %p\n", &y);
	printf("indirizzo (&z) di z = %p\n", &z);	
	printf("px (puntatore) = %p\n", px);
	
	printf("x = %d\n", x);
	printf("y = %d\n", y);
	printf("z = %d\n", z);
	printf("*px = %d\n", *px);
	
	px++;
	*px=50;
	
	printf("DOPO\n");
	printf("indirizzo (&x) di x = %p\n", &x);
	printf("indirizzo (&y) di y = %p\n", &y);
	printf("indirizzo (&z) di z = %p\n", &z);	
	printf("px (puntatore) = %p\n", px);
	
	printf("x = %d\n", x);
	printf("y = %d\n", y);
	printf("z = %d\n", z);
	printf("*px = %d\n", *px);	
		
	return 0;
}
