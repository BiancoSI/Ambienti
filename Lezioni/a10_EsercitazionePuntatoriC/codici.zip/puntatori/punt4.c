#include <stdio.h>
#include <stdlib.h>

int main(){
	long x=10;
	long y=20;
	long z=30;
	long *px;
	
	px=&x;
	
	printf("indirizzo (&x) di x = %p\n", &x);
	printf("indirizzo (&y) di y = %p\n", &y);
	printf("indirizzo (&z) di z = %p\n", &z);	
	printf("px (puntatore) = %p\n", px);
	
	printf("x = %ld\n", x);
	printf("y = %ld\n", y);
	printf("z = %ld\n", z);
	printf("*px = %ld\n", *px);
	
	px++;
	*px=50;
	
	printf("DOPO\n");
	printf("indirizzo (&x) di x = %p\n", &x);
	printf("indirizzo (&y) di y = %p\n", &y);
	printf("indirizzo (&z) di z = %p\n", &z);	
	printf("px (puntatore) = %p\n", px);
	
	printf("x = %ld\n", x);
	printf("y = %ld\n", y);
	printf("z = %ld\n", z);
	printf("*px = %ld\n", *px);	
		
	return 0;
}
