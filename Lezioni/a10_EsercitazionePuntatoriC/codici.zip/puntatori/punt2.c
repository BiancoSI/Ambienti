#include <stdio.h>
#include <stdlib.h>

int main(){
	int x=10;
	int *px;
	
	px=(int*)500;
	*px=0;
		
	return 0;
}
