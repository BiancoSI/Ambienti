#include <stdio.h>
#include <stdlib.h>


int main(){
	int *v;
	int i;
	int n;
	
	printf("inserire la dimensione n del vettore ");
	scanf("%d", &n);
	
	v=(int*)malloc(n*sizeof(int));
	if(v==NULL){
		printf("ERRORE NELLA MALLOC\n");
		return 1;
	}
	
	for(i=0; i<n; i++){
		printf("inserire v[%d] ", i);
		scanf("%d", &v[i]);
	}
	
	for(i=0; i<n; i++){
		printf("v[%d]=%d\n", i, v[i]);
	}
	free(v);
	
	return 0;
}
