#include <stdio.h>
#include <stdlib.h>
#define N 5

int main(){
	int v[N];
	int i;
	int *p;
	
	for(i=0; i<N; i++){
		printf("inserire v[%d] ", i);
		scanf("%d", &v[i]);
	}
	
	for(i=0; i<N; i++){
		printf("v[%d]=%d\n", i, v[i]);
	}
	
	p=v;
	
	for(i=0; i<N; i++){
		printf("v[%d]=%d\n", i, p[i]);
	}
	p=&v[0];	
	for(i=0; i<N; i++){
		printf("v[%d]=%d\n", i, p[i]);
	}
	
	// aritmetica dei puntatori
	for(i=0; i<N; i++){
		printf("v[%d]=%d\n", i, *p);
		p++;
	}
	// ATTENZIONE AL VALORE DI p ALLA FINE DEL CICLO
	p=v;
	// aritmetica dei puntatori
	for(i=0; i<N; i++){
		printf("v[%d]=%d\n", i, *(p+i));
	}
	return 0;
}
