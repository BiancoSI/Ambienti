#include <stdio.h>
#include <stdlib.h>

void leggi(int*, int );
void scrivi(int *, int );
void componi(int *v1, int *v2, int *v3, int n);

int main(){
	int n, i;
	int *v1, *v2, *v3;
	
	printf("Inserire la dim del vettore: ");
	scanf("%d", &n);
	v1=(int*)malloc(n*sizeof(int));
	if(v1==NULL){
		printf("Errore nella malloc \n");
		return 1;
	}
	v2=(int*)malloc(n*sizeof(int));
	if(v2==NULL){
		printf("Errore nella malloc \n");
		return 1;
	}
	v3=(int*)malloc(2*n*sizeof(int));
	if(v3==NULL){
		printf("Errore nella malloc \n");
		return 1;
	}
	
	printf("Inserire gli elemti del primo vettore\n");
	leggi(v1, n);	
	
	printf("Inserire gli elemti del secondo vettore\n");
	leggi(v2, n);
	
	componi(v1, v2, v3, n);
	
	printf("Vettore alternato \n");
	scrivi(v3, 2*n);	
	
	free(v1);
	free(v2);
	free(v3);
}

void leggi(int *v, int n){
	int i;
	for(i=0; i<n; i++){
		printf("array[%d]= ", i);
		scanf("%d", &v[i]);
	}
}
void scrivi(int *v, int n){
	int i;
	for(i=0; i<n; i++){
		printf("%d\t", v[i]);
	}
	printf("\n");
}
void componi(int *v1, int *v2, int *v3, int n){
	int i;
	for(i=0; i<n; i++){
		v3[2*i]=v1[i];
		v3[2*i+1]=v2[i];
	}
}
