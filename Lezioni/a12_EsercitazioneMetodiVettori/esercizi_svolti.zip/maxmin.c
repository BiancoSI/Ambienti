#include <stdio.h>
#include <stdlib.h>

// Dichiarazione dei metodi
void leggiVettore(int*, int);
int max(int*, int);
int min(int*, int);

void maxmin(int *v, int dim, int *max, int *min);

int main(){
	int *v;
	int i, dim, massimo, minimo;
	printf("Inserire la dimensione del vettore: ");
	scanf("%d", &dim);
	// allocazione dinamica del vettore
	v=(int*)malloc(dim*sizeof(int));
	// verifica che ci sia memoria sufficiente
	if(v==NULL){
		printf("Errore nella malloc \n");
		return 1;
	}
	leggiVettore(v, dim);
	/*
	massimo=max(v, dim);
	minimo=min(v, dim);
	*/
	maxmin(v, dim, &massimo, &minimo);
	printf("Il massimo è %d\n", massimo);
	printf("Il minimo è %d\n", minimo);
	// deallocazione della memoria
	free(v);
	return 0;
}

// Implementazione dei metodi
void leggiVettore(int *v, int n){
	int i;
	for(i=0; i<n; i++){
		printf("Inserire v[%d] ", i);
		scanf("%d", &v[i]);
	}
}

int max(int *v, int n){
	int i;
	int m=v[0];
	for(i=0; i<n; i++){
		if(v[i]>m)
			m=v[i];
	}
	return m;
}
int min(int* v, int n){
	int i;
	int m=v[0];
	for(i=0; i<n; i++){
		if(v[i]<m)
			m=v[i];
	}
	return m;
}

void maxmin(int *v, int dim, int *max, int *min){
	int i;
	*max=v[0];
	*min=v[0];
	for(i=0; i<dim; i++){
		if(v[i]>*max)
			*max=v[i];
		if(v[i]<*min)
			*min=v[i];
	}
}

