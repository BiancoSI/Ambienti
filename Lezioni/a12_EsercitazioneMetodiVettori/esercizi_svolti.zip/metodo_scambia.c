#include <stdio.h>
#include <stdlib.h>

// Sezione di dichiarazione dei metodi
void scambia(double *, double *);


// MAIN
int main(){
	double m1, m2;
	printf("Inserire il primo valore: ");
	scanf("%lf", &m1);
	printf("Inserire il secondo valore: ");
	scanf("%lf", &m2);
	scambia(&m1, &m2);
	
	printf("m1=%.2lf  m2=%.2lf \n", m1, m2);
	return 0;
}


// Sezione di implementazione dei metodi
void scambia(double *a, double *b){
	double temp;
	temp=*a;
	*a=*b;
	*b=temp;
}
