#include <stdio.h>
#include <stdlib.h>

// Sezione di dichiarazione dei metodi
void raddoppia(double *, int);


// MAIN
int main(){
	int n, i;
	double *v;
	
	printf("Inserire a dimensione del vettore: ");
	scanf("%d", &n);
	v= (double*) malloc(n*sizeof(double));
	if(v==NULL){
		printf("Errore nella malloc\n");
		return 1;
	}
	
	for(i=0;i<n;i++){
		printf("Inserire l'elemento in posizione %d ", i);
		scanf("%lf", &v[i]);
	}
	raddoppia(v, n);
	for(i=0;i<n;i++)
		printf("%.2lf\t", v[i]);
	printf("\n");
	free(v);
	return 0;
}


// Sezione di implementazione dei metodi
void raddoppia(double *v,  int n){
	int i;
	for(i=0; i<n; i++){
		v[i]=2*v[i];
	}
}
