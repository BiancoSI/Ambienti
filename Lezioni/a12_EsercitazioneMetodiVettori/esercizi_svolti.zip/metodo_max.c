#include <stdio.h>
#include <stdlib.h>

// Sezione di dichiarazione dei metodi
double max(double, double);
// double max(double a, double b);


// MAIN
int main(){
	double m1, m2, ris;
	printf("Inserire il primo valore: ");
	scanf("%lf", &m1);
	printf("Inserire il secondo valore: ");
	scanf("%lf", &m2);
	ris=max(m1, m2);
	printf("Il massimo è %.2lf\n", ris);
	return 0;
}


// Sezione di implementazione dei metodi
double max(double a, double b){
	double massimo;
	massimo=a;
	if(b>massimo)
		massimo=b;
	return massimo;
}
