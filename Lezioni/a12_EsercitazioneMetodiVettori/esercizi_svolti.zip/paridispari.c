#include <stdio.h>
#include <stdlib.h>

// Dichiarazione dei metodi
void leggiVettore(int*, int);
int parimagdis(int*, int);


int main(){
	int *v;
	int i, dim, parimaggiore; 
	printf("Inserire la dimensione del vettore: ");
	scanf("%d", &dim);
	// allocazione dinamica del vettore
	v=(int*)malloc(dim*sizeof(int));
	// verifica che ci sia memoria sufficiente
	if(v==NULL){
		printf("Errore nella malloc \n");
		return 1;
	}
	leggiVettore(v, dim);
	parimaggiore= parimagdis(v, dim);
	if(parimaggiore)
		printf("Pari sono maggiori dei dispari\n");
	else
		printf("Dispari sono maggiori dei pari\n");
	// deallocazione della memoria
	free(v);
	return 0;
}

// Implementazione dei metodi
void leggiVettore(int *v, int n){
	int i;
	for(i=0; i<n; i++){
		printf("Inserire v[%d] ", i);
		scanf("%d", &v[i]);
	}
}

int parimagdis(int *v, int n){
	int pari=0;
	int dispari=0;
	int i;
	for(i=0; i<n; i++){
		if(v[i]%2==0) // elemento pari
			pari=pari+v[i];
		else 
			dispari+=v[i];
	}
	return pari>dispari;
}

