echo -n "Inserisci X>"
read x
if [ $x -lt 10 ];then 
	echo "X=$x minore di 10";
else
	echo "X=$x maggiore uguale 10";
fi
