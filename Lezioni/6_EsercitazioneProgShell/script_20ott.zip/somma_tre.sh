if [ $# -ne 3 ];then 
      echo "Uso: $0 <num1><num2><num3>"
      exit 1
fi
let somma=$1+$2+$3
echo "Passati $#  argomenti"
echo Somma=$somma
echo "la chiocciola stampa $@"
