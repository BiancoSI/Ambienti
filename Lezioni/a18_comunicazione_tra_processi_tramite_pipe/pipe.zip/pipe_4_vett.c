#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
// P legge da stdin un vett, invia a F che fa la media e la manda a P che lo scrive su stdout
// F non conserva il vettore
#define N 5
int main(){
	int pid;
	int pdP2F[2];
	int pdF2P[2];
	int status;
	
	if(pipe(pdP2F)==-1){
		printf("Errore nella creazione della pipe\n");
		exit(1);
	}
	if(pipe(pdF2P)==-1){
		printf("Errore nella creazione della pipe\n");
		exit(1);
	}
	pid=fork();
	if(pid==-1){
		printf("Errore nella fork\n");
		exit(-1);
	}
	else if(pid==0){ //Proc Figlio
		float media;
		int x;
		int i;
		close(pdP2F[1]);
		for(i=0;i<N;i++){
			read(pdP2F[0], &x, sizeof(int));
			media+=x;
		}
		close(pdP2F[0]);
		media = media/N;
		close(pdF2P[0]);
		write(pdF2P[1], &media, sizeof(float));
		close(pdF2P[1]);
		exit(0);	
	}	
	else{ // Proc Padre
		float x;
		int v[N];
		int i;
		//leggi v da stdin
		for(i=0; i<N;i++){
			printf("Inserire v[%d]: ", i);
			scanf("%d", &v[i]);
		}
		close(pdP2F[0]);
		write(pdP2F[1], v, N*sizeof(int));
		close(pdP2F[1]);
		wait(&status); // anche alla fine
		close(pdF2P[1]);
		read(pdF2P[0], &x, sizeof(float));
		close(pdF2P[0]);
		printf("P: la media del vettore è %.2f\n", x);	
	}
}	
