#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
// Somma parallela (si ipotizza che il vettore sia di dim multipla del #figli)
#define NFIGLI 3
#define N 9

void scrivi(int* v, int n, int figlio){
	int i;
	printf("F %d: ", figlio);
	for(i=0; i<n; i++){
		printf("%d\t", v[i]);
	}
	printf("\n");		
}

int main(){
	int pid = 10;
	int i;
	int nfiglio;
	int pdP2F[2];
	int pdF2P[2];
	int status;
	
	if(pipe(pdP2F)==-1){
		printf("Errore nella pipe\n");
		exit(1);
	}
	if(pipe(pdF2P)==-1){
		printf("Errore nella pipe\n");
		exit(1);
	}
	
	for(i=0;i<NFIGLI;i++){
		if(pid>0){
			nfiglio=i;
			pid=fork();
			if(pid==-1){
				printf("Errore nella fork\n");
				exit(1);
			}
		}
	}
	if(pid>0){// sono il padre
		int v[N];
		int sommatot=0;
		int sommaparz=0;
		//leggiVettore
		for(i=0;i<N;i++){
			printf("Inserire v[%d]= ", i);
			scanf("%d", &v[i]);
		}
		// scrivi il vettore ai figli
		close(pdP2F[0]);
		write (pdP2F[1],v, N*sizeof(int));
		close(pdP2F[1]);
		// leggi risult parziali dai figli
		close(pdF2P[1]);
		for(i=0;i<NFIGLI;i++){
			read(pdF2P[0], &sommaparz, sizeof(int));
			sommatot+=sommaparz;
		}
		close(pdF2P[0]);
		printf("Somma tot = %d\n", sommatot);
		// Aspetta terminazione figli
		for(i=0;i<NFIGLI;i++){
			wait(&status);
		}
	}
	else if(pid==0){// figli
		int sommaparz=0;
		int v[N/NFIGLI];
		// leggi porzione di vettore
		close(pdP2F[1]);
		read(pdP2F[0], v, N/NFIGLI*sizeof(int));
		close(pdP2F[0]);
		scrivi(v, N/NFIGLI, nfiglio);
		// somma parziale
		for(i=0;i<N/NFIGLI;i++){
			sommaparz+=v[i];
		}
		printf("F %d: somma parz= %d\n", nfiglio, sommaparz);
		// scrivi somma parz
		close(pdF2P[0]);
		write(pdF2P[1], &sommaparz, sizeof(int));
		close(pdF2P[1]);
		exit(0);
	}
	return 0;
}
