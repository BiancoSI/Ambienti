#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
// P legge da stdin, invia a F che scrive su stdout
int main(){
	int pid;
	int pd[2];
	int status;
	
	if(pipe(pd)==-1){
		printf("Errore nella creazione della pipe\n");
		exit(1);
	}
	pid=fork();
	if(pid==-1){
		printf("Errore nella fork\n");
		exit(-1);
	}
	else if(pid==0){ //Proc Figlio
		int x;
		close(pd[1]);
		read(pd[0], &x, sizeof(int));
		close(pd[0]);
		printf("F: ho ricevuto il numero %d\n", x);
		exit(0);	
	}	
	else{ // Proc Padre
		int x;
		printf("P: Inserire un intero: ");
		scanf("%d", &x);
		close(pd[0]);
		write(pd[1], &x, sizeof(int));
		close(pd[1]);
		wait(&status);
	}
}	
