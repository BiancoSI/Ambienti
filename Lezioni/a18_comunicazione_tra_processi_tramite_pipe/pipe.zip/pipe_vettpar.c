#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>

#define NFIGLI 3
#define DIM 9
int main()
{
	int pid=10;
	int i;
	int status;
	int nfiglio;
	int porzione;
	int vett[]={10,20,30,40,50,60,70,80,90};
	int pd[2];
	int inizio, fine;

	porzione=DIM/NFIGLI;   // 3

	pipe(pd);
	for (i=0;i<NFIGLI;i++){
		if (pid>0){
		     nfiglio=i;
		     inizio=porzione*nfiglio;   fine=inizio+porzione -1;
		     pid=fork();
		}
	}
	if (pid>0)
	{
		int sommatot,sommaparz,i,status;
		//codice padre
		sommatot=0;
		for (i=0;i<NFIGLI;i++){
			read  (pd[0],&sommaparz,sizeof(int));
			sommatot+=sommaparz;
		}
		printf("Padre: Somma totale=%d\n", sommatot);
		for (i=0;i<NFIGLI;i++)
			wait(&status);
	}
	else if (pid==0){
		int sommaparz,i;
		sommaparz=0;
		for (i=inizio;i<=fine;i++)
			sommaparz+=vett[i];
		printf ("SOno il figlio %d, la mia somma è:%d\n",nfiglio, sommaparz);
		write(pd[1],&sommaparz,sizeof(int));
		exit(0);
	}
	return 0;
}
