#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
// P legge da stdin, invia a F che lo raddoppia e lo rimanda a P che lo scrive su stdout
int main(){
	int pid;
	int pdP2F[2];
	int pdF2P[2];
	int status;
	
	if(pipe(pdP2F)==-1){
		printf("Errore nella creazione della pipe\n");
		exit(1);
	}
	if(pipe(pdF2P)==-1){
		printf("Errore nella creazione della pipe\n");
		exit(1);
	}
	pid=fork();
	if(pid==-1){
		printf("Errore nella fork\n");
		exit(-1);
	}
	else if(pid==0){ //Proc Figlio
		int x;
		close(pdP2F[1]);
		read(pdP2F[0], &x, sizeof(int));
		close(pdP2F[0]);
		printf("F: ho ricevuto il numero %d\n", x);
		x=2*x;
		close(pdF2P[0]);
		write(pdF2P[1], &x, sizeof(int));
		close(pdF2P[1]);
		exit(0);	
	}	
	else{ // Proc Padre
		int x;
		printf("P: Inserire un intero: ");
		scanf("%d", &x);
		close(pdP2F[0]);
		write(pdP2F[1], &x, sizeof(int));
		close(pdP2F[1]);
		wait(&status); // anche alla fine
		close(pdF2P[1]);
		read(pdF2P[0], &x, sizeof(int));
		close(pdF2P[0]);
		printf("P: il doppio calcolato da mio figlio è %d\n", x);
		
		
	}
}	
