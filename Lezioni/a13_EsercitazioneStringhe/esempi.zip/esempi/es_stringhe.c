#include <stdio.h>
#include <string.h>

int main(){
	char nome[100]="Marco";
	char nome2[100];
	char nome3[100];
	char nome4[100];
	char nome5[100];
	char nome6[100];
	char nome7[200];
	char *pstring;
	int lung, i, x;
	//char nome[]="Marco";
	//nome = "Giovanni";  // errore
	
	// strcpy
	strcpy(nome, "Giovanni");
	
	//input
	printf("Come ti chiami?\n");
	scanf("%s", nome2);
	printf("Benvenuto %s\n", nome2);
	
	//strlen
	lung=strlen(nome2);
	printf("La lunghezza del tuo nome è %d\n", lung);
	printf("Lo spelling del tuo nome è:\n");
	for(i=0;i<lung;i++)
		printf("%c\n", nome2[i]);
		
	//strcmp
	printf("Inserire il primo nome ");
	scanf("%s", nome3);
	printf("Inserire il secondo nome ");
	scanf("%s", nome4);
	x=strcmp(nome3, nome4);
	if(x==0)
		printf("I due nomi sono uguali\n");
	else if(x<0)
		printf("%s precede %s \n", nome3, nome4);
	else	
		printf("%s precede %s \n", nome4, nome3);
	
	//strcat
	strcat(nome3, nome4);
	printf("La concatenazione è %s\n", nome3);
	
	//sprintf
	printf("Inserire il primo nome ");
	scanf("%s", nome5);
	printf("Inserire il secondo nome ");
	scanf("%s", nome6);
	sprintf(nome7, "%s%s", nome5, nome6); //Concatenazione
	printf("La concatenazione è %s\n", nome7);
	sprintf(nome7, "%s", nome5); // Copia
	printf("nome7=%s\n", nome7);
	
	sprintf(nome7, "%d", lung); // Conversione
	printf("La var lung è pari a %s\n", nome7);
	printf("La var lung è pari a %d\n", lung);
	
	return 0;
}
