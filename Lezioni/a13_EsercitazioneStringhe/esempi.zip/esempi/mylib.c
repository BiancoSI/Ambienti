// Implementazioni dei metodi
#include "mylib.h"
int raddoppia(int x){
	return 2*x;
}
