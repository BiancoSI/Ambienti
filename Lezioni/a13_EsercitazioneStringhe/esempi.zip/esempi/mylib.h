//Intestazione dei metodi 
int raddoppia(int);
