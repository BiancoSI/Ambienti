#include <stdio.h>
#include "mylib.h"

int main(){
	int x;
	printf("Inserire un valore > ");
	scanf("%d", &x);
	printf("Il doppio del valore inserito è %d\n", raddoppia(x));
	return 0;
}
