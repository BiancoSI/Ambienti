#include <stdio.h>

int main(){
	printf("Hello world\n");
	printf("Questo è il mio primo programma scritto in C \n");
	return 0;
}
