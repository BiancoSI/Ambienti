#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>

int main()
{
	int pid;
	int x=10;
	int status;
	
	printf("Codice prima della fork\n");
	pid=fork();
	// duplicato per processo padre e figlio
	if (pid==-1){
		printf("Errore nella fork\n");exit(1);}
	else if (pid==0){
		int pidnip;
		printf("Sono il figlio\n");
		pidnip=fork();
		if (pidnip==0){  // codice nipote
			printf("Sono il nipote\n");
			exit(0);
		}
		else if (pidnip>0){
		printf("Sono ancora il figlio\n");
		sleep(10);
		wait (&status); //aspetto il nipote
		exit(5);
		}
		
	}
	else{   //>0 padre
		int pid2;
		printf("Sono il padre \n");
		wait (&status);
		printf("Figlio terminato\n");
		
	}
	return 0;
}
