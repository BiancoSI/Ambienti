#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define N 5

int main(){
	int pid;
	int status;
	int nfiglio;
	int i;	
	int pid_figlio;
	pid = 1; // valore positivo per entrare la prima volta nel for
	for(i=0; i<N;i++){
		if(pid>0){
			nfiglio=i;
			pid=fork();
			if(pid==-1){
				printf("Errore nella fork\n");
				exit(1);
			}
		}
	}
	if(pid>0){
		//codice padre
		printf("Codice padre\n");
		// wait su tutti i figli
		for(i=0;i<N;i++){
			pid_figlio = wait(&status);
			printf("Figlio %d terminato\n", pid_figlio);
		}
	}
	else if(pid==0){
		printf("Sono il figlio %d\n", nfiglio);
		exit(0);
	}

	return 0;
}

