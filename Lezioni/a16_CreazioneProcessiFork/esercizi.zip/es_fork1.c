#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	int pid;
	int x;
	
	x=10;
	
	printf("Prima della fork\n");
	pid = fork();
	// da qui in poi abbiamo P ed F
	if(pid==-1){
		printf("Errore nella fork\n");
		exit(1);
	} else if(pid == 0){  // Figlio
		printf("Sono il figlio con pid %d e mio padre ha pid %d\n", getpid(), getppid());
		x = 20;
		sleep(10);
		printf("F: x=%d\n", x);
		printf("Termina il figlio");
	
	}
	else{  // >0 Padre
		printf("Sono il padre con pid %d e ho generato un figlio con pid %d\n", getpid(), pid);
		sleep(8);
		printf("P: x=%d\n", x);
		printf("Termina il padre");
	}
	
	
	//printf("Dopo la fork\n");

	return 0;
}

