#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>

int main()
{
	int pid;
	int status;
	
	printf("Codice prima della fork\n");
	pid=fork();
	// duplicato per processo padre e figlio
	if (pid==-1){
		printf("Errore nella fork\n");exit(1);}
	else if (pid==0){
		printf("Sono il figlio\n");
		execl ("/bin/ls","ls","-l","-trh", NULL);
		printf ("Errore nella execl\n");
		
	}
	else{   //>0 padre
		printf("Sono il padre\n");
		wait(&status);
	}
	return 0;
}
