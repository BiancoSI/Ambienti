#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	int pid;
	int x;
	int status;
	
	x=10;
	
	printf("Prima della fork\n");
	pid = fork();
	// da qui in poi abbiamo P ed F
	if(pid==-1){
		printf("Errore nella fork\n");
		exit(1);
	} else if(pid == 0){  // Figlio
		printf("Sono il figlio con pid %d e mio padre ha pid %d\n", getpid(), getppid());
		x = 20;
		sleep(5);
		exit(5);
		
	
	}
	else{  // >0 Padre
		int pidfiglio;
		printf("Sono il padre con pid %d e ho generato un figlio con pid %d\n", getpid(), pid);
		sleep(1);
		pidfiglio = wait(&status);
		printf("Figlio con pid %d terminato con codice %d\n", pidfiglio, status/256);
		
		
	}
	
	
	//printf("Dopo la fork\n");

	return 0;
}

