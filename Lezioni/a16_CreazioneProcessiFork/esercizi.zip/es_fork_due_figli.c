#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	int pid;
	int status;
	int nfiglio=1;	
	pid = fork();
	// da qui in poi abbiamo P ed F
	if(pid>0){
		//sono il padre e creo un altro figlio
		nfiglio = 2;
		pid=fork();
	}
	// da qui in poi ci sono P, F1 e F2
	switch(pid){
		case -1: printf("errore fork\n"), exit(1); break;
		case 0: // codice figli
			if(nfiglio==1)
				printf("Sono il figio 1 con pid %d\n", getpid());
			else
				printf("Sono il figio 2 con pid %d\n", getpid());
			break;
		default:
			printf("Sono il padre\n");
			int pid_figlio;
			pid_figlio = wait(&status);
			printf("Figlio %d terminato\n", pid_figlio);
			pid_figlio = wait(&status);
			printf("Figlio %d terminato\n", pid_figlio);
	}
	return 0;
}

