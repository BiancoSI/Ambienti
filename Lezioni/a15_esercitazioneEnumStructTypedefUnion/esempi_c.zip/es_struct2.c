#include <stdio.h>

typedef enum{picche, cuori, quadri, fiori} seme;

typedef struct{
	int val;
	seme s;
} carta;

int main(){
	carta c;
	char* semi[]={"picche", "cuori", "quadri", "fiori"};
	
	c.val = 5;
	c.s = cuori;
	
	printf("La carta è un %d di %d\n", c.val, c.s);
	printf("La carta è un %d di %s\n", c.val, semi[c.s]);

}
