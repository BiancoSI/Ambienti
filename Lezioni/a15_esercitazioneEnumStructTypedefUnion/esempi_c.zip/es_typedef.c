#include <stdio.h>
#define N 4
#define false 0
#define true 1

typedef int boolean;

int main(){
	int v[] = {1, 3, 2, 15};
	int x;
	int i;
	boolean trovato;
	
	printf("Inserire l'elemento da cercare ");
	scanf("%d", &x);
	
	trovato = false; // false
	for(i=0; i<N && !trovato; i++){
		if(x==v[i])
			trovato=true;
	}	
	if(trovato)
		printf("%d è presente nel vettore\n", x);
	else
		printf("%d non è presente nel vettore\n", x);

	return 0;
}
