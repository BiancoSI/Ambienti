#include <stdio.h>

typedef union{
	int int_val;
	float float_val;
} number;

typedef enum{INT, FLOAT} type_number;

int main(){
	number n;
	type_number n_type;
	n.int_val = 5;
	n_type = INT;
	//printf("n=%d\n", n.int_val);
	n.float_val = 5.3;
	n_type = FLOAT;
	//printf("n=%f\n", n.float_val);
	
	if(n_type == INT)
		printf("n=%d\n", n.int_val);
	else
		printf("n=%f\n", n.float_val);
	
	
	return 0;
}
