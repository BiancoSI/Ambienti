// tipo punto con le coordinate
// tipo cerchio centro (punto) e raggio
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

typedef struct{
	float x;
	float y;
} punto;

typedef struct{
	punto centro;
	float raggio;
} cerchio;

float distanza(punto, punto);
float area(cerchio);

int main(){
	punto p1;
	cerchio c;
	punto *p_punt;
	cerchio *cerchi;
	
	cerchi = (cerchio*) malloc(10*sizeof(cerchio)); // array dinamico di 10 cerchi
	free(cerchi);
	
	p1.x = 3.2;
	p1.y = 5.4;
	p_punt = &p1;
	printf("L'ascissa di p1 è %.2f\n", (*p_punt).x);
	
	printf("L'ascissa di p1 è %.2f\n", p_punt->x);
	
	printf("Inserire l'ascissa del centro del cerchio ");
	scanf("%f", &p1.x);
	printf("Inserire l'ordinata del centro del cerchio ");
	scanf("%f", &p1.y);
	printf("Inserire il raggio del cerchio ");
	scanf("%f", &c.raggio);
	c.centro = p1;
	printf("L'area del cerchio è %.2f\n", area(c));
	return 0;
}

float distanza(punto p1, punto p2){
	float dx=p1.x - p2.x;
	float dy= p1.y - p2.y;
	// per compilare utilizzare l'opzione -lm
	return sqrt(dx*dx+dy*dy);
}

float area(cerchio c){
	return 3.14*c.raggio*c.raggio;
}


